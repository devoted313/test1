﻿using Microsoft.VisualBasic;
using EMS;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Runtime.InteropServices;

static class Utility
{
    public static int staffId = 0;
    public static string statffName = string.Empty;

    public static ColumnHeader SortingColumn = null;
    public static string GetStaffID()
    {
        string staffID = "";

        SQLConn.sql = "SELECT StaffID FROM staff ORDER BY StaffID DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                staffID = (Convert.ToInt32(SQLConn.reader["StaffID"]) + 1).ToString();
            }
            else
            {
                staffID = "1";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return staffID;
    }

    public static string GetMeasureUnitID()
    {
        string unitMeasureID = "";

        SQLConn.sql = "SELECT measure_unit_id FROM measure_unit ORDER BY measure_unit_id DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {

            if (SQLConn.reader.Read() == true)
            {
                unitMeasureID = (Convert.ToInt32(SQLConn.reader["measure_unit_id"]) + 1).ToString();
            }
            else
            {
                unitMeasureID = "1";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return unitMeasureID;
    }

    public static string GetStockInNo()
    {
        string stockInNo = "";

        SQLConn.sql = "SELECT StockInNo FROM stockin ORDER BY StockInNo DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {

            if (SQLConn.reader.Read() == true)
            {
                stockInNo = (Convert.ToInt32(SQLConn.reader["StockInNo"]) + 1).ToString();
            }
            else
            {
                stockInNo = "1";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return stockInNo;
    }

    public static string GetCategoryNo()
    {
        string categoryNo = "";

        SQLConn.sql = "SELECT CategoryNo FROM category ORDER BY CategoryNo DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {

            if (SQLConn.reader.Read() == true)
            {
                categoryNo = (Convert.ToInt32(SQLConn.reader["CategoryNo"]) + 1).ToString();
            }
            else
            {
                categoryNo = "1";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return categoryNo;
    }

    public static string GetNextInvoiceNo()
    {
        string invoiceNo = "";

        SQLConn.sql = "SELECT transactionid FROM transactions ORDER BY transactionid DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {

            if (SQLConn.reader.Read() == true)
            {
                invoiceNo = (Convert.ToInt32(SQLConn.reader["transactionid"]) + 1).ToString();
            }
            else
            {
                invoiceNo = "1";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return invoiceNo;
    }

    public static bool GetInvoiceNo(string p_sInvoiceNo)
    {
        bool bExistsinvoiceNo = true;

        SQLConn.sql = "SELECT distinct transactionid FROM transactions where transactionid = '" + p_sInvoiceNo + "'";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExistsinvoiceNo = true;
            }
            else
            {
                bExistsinvoiceNo = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExistsinvoiceNo;
    }

    public static string GetTransactionStatus(int pItransactionNo)
    {
        string sStatus = "";

        SQLConn.sql = "SELECT distinct status FROM transactions where transactionid =" + pItransactionNo;
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                if((int)SQLConn.reader["status"] == 0)
                    sStatus = "Validée";
                else
                    sStatus = "A valider";
            }
            else
            {
                sStatus = "En cours";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return sStatus;
    }

    public static string GetPartnerID()
    {
        string partnerID = "";

        SQLConn.sql = "SELECT partner_id FROM partner ORDER BY partner_id DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {

            if (SQLConn.reader.Read() == true)
            {
                partnerID = (Convert.ToInt32(SQLConn.reader["partner_id"]) + 1).ToString();
            }
            else
            {
                partnerID = "1";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return partnerID;
    }

    public static string GetApplicationID()
    {
        string applicationID = "";

        SQLConn.sql = "SELECT application_id FROM application ORDER BY application_id DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {

            if (SQLConn.reader.Read() == true)
            {
                applicationID = SQLConn.reader["application_id"].ToString();
            }
            else
            {
                applicationID = "";
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return applicationID;
    }

    public const int WM_NCLBUTTONDOWN = 0xA1;
    public const int HT_CAPTION = 0x2;

    [DllImportAttribute("user32.dll")]
    public static extern int SendMessage(IntPtr hWnd,
                     int Msg, int wParam, int lParam);
    [DllImportAttribute("user32.dll")]
    public static extern bool ReleaseCapture();

    public static void onlynumwithsinglecomma(object sender, KeyPressEventArgs e)
    {
        if (!(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == ','))
        { e.Handled = true; }
        TextBox txtDecimal = sender as TextBox;
        if (e.KeyChar == ',' && txtDecimal.Text.Contains(","))
        {
            e.Handled = true;
        }
    }

    public static int GetProductStock(int p_iProductNo)
    {
        int iStocksonhand = 0;

        SQLConn.sql = "SELECT distinct stocksonhand FROM product where productno = " + p_iProductNo;
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                iStocksonhand = (Convert.ToInt32(SQLConn.reader["stocksonhand"]));
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return iStocksonhand;
    }

    public static bool ItemMatches(ListViewItem item, string text)
    {
        bool matches = false;

        matches |= item.Text.ToLower().Contains(text.ToLower());

        if (matches)
        {
            return true;
        }

        foreach (ListViewItem.ListViewSubItem subitem in item.SubItems)
        {
            matches |= subitem.Text.ToLower().Contains(text.ToLower());
            if (matches)
            {
                return true;
            }
        }

        return false;
    }

    public static void AddStockIn(int p_iProductId, string p_sQuantity, int p_iTypetransaction, int p_iTransactionSatuts)
    {
        try
        {
            SQLConn.sql = "INSERT INTO StockIn(StockInNo, ProductNo, Quantity, DateIn, Status) Values('" + Utility.GetStockInNo() + "', '" + p_iProductId + "', '" + p_sQuantity + "', '" + System.DateTime.Now.ToString("dd/MM/yyyy") + "', " + p_iTransactionSatuts + ")";
            SQLConn.ConnDB();
            SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
            SQLConn.command.ExecuteNonQuery();
            //Interaction.MsgBox("Le stock a été modifié avec succès.", MsgBoxStyle.Information, "Entrée de Stock");

            if(p_iTransactionSatuts == 0)
                UpdateProductQuantity(p_sQuantity, p_iProductId, p_iTypetransaction);
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }
    }

    public static void AddStockOut(int p_iProductId, string p_sQuantity, int p_iTypetransaction, int p_iTransactionSatuts)
    {
        try
        {
            SQLConn.sql = "INSERT INTO StockOut(StockOutNo, ProductNo, Quantity, DateOut, Status) Values('" + Utility.GetStockInNo() + "', '" + p_iProductId + "', '" + p_sQuantity + "', '" + System.DateTime.Now.ToString("dd/MM/yyyy") + "', " + p_iTransactionSatuts + ")";
            SQLConn.ConnDB();
            SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
            SQLConn.command.ExecuteNonQuery();
            //Interaction.MsgBox("Le stock a été modifié avec succès.", MsgBoxStyle.Information, "Sortie de Stock");
            if (p_iTransactionSatuts == 0)
                UpdateProductQuantity(p_sQuantity, p_iProductId, p_iTypetransaction);
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }
    }

    public static void UpdateProductQuantity(string p_sQuantity, int p_iProductId, int p_iTypetransaction)
    {
        try
        {
            if(p_iTypetransaction == 0 || p_iTypetransaction == 2)
                SQLConn.sql = "UPDATE Product SET StocksOnhand = StocksOnHand + '" + Conversion.Val(p_sQuantity.Replace(",", "")) + "' WHERE ProductNo = '" + p_iProductId + "'";

            if (p_iTypetransaction == 1)
                SQLConn.sql = "UPDATE Product SET StocksOnhand = StocksOnHand - '" + Conversion.Val(p_sQuantity.Replace(",", "")) + "' WHERE ProductNo = '" + p_iProductId + "'";

            SQLConn.ConnDB();
            SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
            SQLConn.command.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }
    }

    public static int GetNextTransactionDetailsId()
    {
        int transactionDetailsID = 1;

        SQLConn.sql = "SELECT TDetailNo FROM transactiondetails ORDER BY TDetailNo DESC";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {

            if (SQLConn.reader.Read() == true)
            {
                transactionDetailsID = Convert.ToInt32(SQLConn.reader["TDetailNo"]) + 1;
            }
            else
            {
                transactionDetailsID = 1;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return transactionDetailsID;
    }

    public static bool isCategoryExistInProductTable(int p_CategoryNo)
    {
        bool bExists = true;

        SQLConn.sql = "Select count(*) from category where CategoryNo in (select CategoryNo from product where CategoryNo = " + p_CategoryNo + ")";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExists = true;
            }
            else
            {
                bExists = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExists;
    }

    public static bool isMeasureExistInProductTable(int p_measure_unit_id)
    {
        bool bExists = true;

        SQLConn.sql = "select count(*) from measure_unit where measure_unit_id in (select measure_unit_id from product where measure_unit_id = " + p_measure_unit_id + ")";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExists = true;
            }
            else
            {
                bExists = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExists;
    }

    public static bool isLocationExistInProductTable(int p_location_id)
    {
        bool bExists = true;

        SQLConn.sql = "select count(*) from location where location_id in (select location_id from product where location_id = " + p_location_id + ")";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExists = true;
            }
            else
            {
                bExists = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExists;
    }

    public static bool isPartnerExistInProductTable(int p_partner_id)
    {
        bool bExists = true;

        SQLConn.sql = "select count(*) from partner where partner_id in (select partner_id from product where partner_id = " + p_partner_id + ")";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExists = true;
            }
            else
            {
                bExists = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExists;
    }

    public static bool isProductExistInTransactionDetailsTable(int p_productno)
    {
        bool bExists = true;

        SQLConn.sql = "select count(*) from transactiondetails where productno in (select productno from product where productno = " + p_productno + ")";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExists = true;
            }
            else
            {
                bExists = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExists;
    }

    public static bool isProductExistInStockOutTable(int p_productno)
    {
        bool bExists = true;

        SQLConn.sql = "select count(*) from stockout where productno in (select productno from stockout where productno = " + p_productno + ")";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExists = true;
            }
            else
            {
                bExists = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExists;
    }

    public static bool isProductExistInStockInTable(int p_productno)
    {
        bool bExists = true;

        SQLConn.sql = "select count(*) from stockin where productno in (select productno from stockout where productno = " + p_productno + ")";
        SQLConn.ConnDB();
        SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
        SQLConn.reader = SQLConn.command.ExecuteReader();

        try
        {
            if (SQLConn.reader.Read() == true)
            {
                bExists = true;
            }
            else
            {
                bExists = false;
            }
        }
        catch (Exception ex)
        {
            Interaction.MsgBox(ex.ToString());
        }
        finally
        {
            SQLConn.command.Dispose();
            SQLConn.connection.Close();
        }

        return bExists;
    }

    public static void ExportToExcel(DataGridView dgv)
    {
        Microsoft.Office.Interop.Excel._Application excel = new Microsoft.Office.Interop.Excel.Application();
        Microsoft.Office.Interop.Excel._Workbook workbook = excel.Workbooks.Add(Type.Missing);
        Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

        try
        {
            worksheet = (Microsoft.Office.Interop.Excel._Worksheet)workbook.ActiveSheet;

            worksheet.Name = "Exported From DataGrid";

            int cellRowIndex = 1;
            int cellColumnIndex = 1;

            for (int i = -1; i < dgv.Rows.Count; i++)
            {
                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    if (cellRowIndex == 1)
                    {
                        worksheet.Cells[cellRowIndex, cellColumnIndex] = dgv.Columns[j].HeaderText;
                    }
                    else
                    {
                        worksheet.Cells[cellRowIndex, cellColumnIndex] = dgv.Rows[i].Cells[j].Value.ToString();
                    }
                    cellColumnIndex++;
                }
                cellColumnIndex = 1;
                cellRowIndex++;
            }

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx";
            saveDialog.FilterIndex = 1;

            if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                excel.Columns.AutoFit();
                workbook.SaveAs(saveDialog.FileName);
                MessageBox.Show("Export réussi!");
            }
        }

        catch (System.Exception ex)
        {
            MessageBox.Show(ex.Message);
        }
        finally
        {
            excel.Quit();
            workbook = null;
            excel = null;
        }
    }
}
