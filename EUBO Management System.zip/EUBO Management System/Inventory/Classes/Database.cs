﻿using System;
using System.Configuration;

public class Database
{
    static public String ConnectionString
    {
        get
        {    // get connection string with name  database from  web.config.
            return ConfigurationManager.ConnectionStrings["DB"].ConnectionString;
        }
    }
}
