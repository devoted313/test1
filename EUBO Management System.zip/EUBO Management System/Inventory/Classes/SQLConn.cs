using Microsoft.VisualBasic;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EMS
{
    static class SQLConn
	{
		public static string ServerMySQL;
		public static string PortMySQL;
		public static string UserNameMySQL;
		public static string PwdMySQL;
		public static string DBNameMySQL;
		public static string sql;
		public static DataSet dataset = new DataSet();
		public static SqlCommand command;
		public static SqlDataReader reader;

        public static bool adding;
        public static bool updating;
        public static bool deleting;

        public static string strSearch = "";

        public static string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DB"].ConnectionString;
		public static SqlDataAdapter da = new SqlDataAdapter();

		public static SqlConnection connection = new SqlConnection();
		public static void getData()
		{
			string AppName = Application.ProductName;

			try {
				DBNameMySQL = Interaction.GetSetting(AppName, "DBSection", "DB_Name", "temp");
				ServerMySQL = Interaction.GetSetting(AppName, "DBSection", "DB_IP", "temp");
				PortMySQL = Interaction.GetSetting(AppName, "DBSection", "DB_Port", "temp");
				UserNameMySQL = Interaction.GetSetting(AppName, "DBSection", "DB_User", "temp");
				PwdMySQL = Interaction.GetSetting(AppName, "DBSection", "DB_Password", "temp");
			} catch {
				Interaction.MsgBox("System registry was not established, you can set/save " + "these settings by pressing F1", MsgBoxStyle.Information);
			}

		}

		public static void ConnDB()
		{
            connection.Close();
			try {
                connection.ConnectionString = connectionString;

                connection.Open();
			} catch  {
				Interaction.MsgBox("Le syst�me n'a pas r�ussi � �tablir la connexion", MsgBoxStyle.Information, "Connection � la base de donn�es");
			}

		}


		public static void DisconnMy()
		{
            connection.Close();
            connection.Dispose();

		}

		public static void SaveData()
		{
			string AppName = Application.ProductName;

			Interaction.SaveSetting(AppName, "DBSection", "DB_Name", DBNameMySQL);
			Interaction.SaveSetting(AppName, "DBSection", "DB_IP", ServerMySQL);
			Interaction.SaveSetting(AppName, "DBSection", "DB_Port", PortMySQL);
			Interaction.SaveSetting(AppName, "DBSection", "DB_User", UserNameMySQL);
			Interaction.SaveSetting(AppName, "DBSection", "DB_Password", PwdMySQL);

			Interaction.MsgBox("Database connection settings are saved.", MsgBoxStyle.Information);
		}



	}
}

