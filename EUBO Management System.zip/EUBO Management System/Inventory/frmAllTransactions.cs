﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Data.SqlClient;
using LVWComparer;
using System.Data;
using System.Collections.Generic;

namespace EMS
{
    public partial class frmAllTransactions : Form
    {
        public frmAllTransactions()
        {
            InitializeComponent();
        }

        private void DisplayTransactions()
        {
            // prevent flickering
            ListView1.BeginUpdate();

            // restore all items in case user deletes some characters in the textbox
            //ReinitList();

            string search = txtTransaction.Text;

            Transactions(dtStartDate.Value, dtEndDate.Value, search);

            // Search items in our Jobs ListView, remove those that do not match search
            if (search != String.Empty)
            {
                //LoadProducts(search);

                for (int i = ListView1.Items.Count - 1; i >= 0; i--)
                {
                    ListViewItem currentItem = ListView1.Items[i];
                    if (Utility.ItemMatches(currentItem, search))
                    {
                        // highlight, or move highlighting to ItemMatches
                    }
                    else
                    {
                        ListView1.Items.RemoveAt(i);
                    }
                }
            }
            else
                Transactions(dtStartDate.Value, dtEndDate.Value, search);

            ListView1.EndUpdate();
        }

        public void Transactions(DateTime startDate, DateTime endDate, string searchString)
        {

            try
            {
                //SQLConn.sql = "SELECT sr.SalesReturnId, sr.ReturnDate, sr.InvoiceNo, CONCAT(s.lastname, ', ', s.firstname, ' ', s.MI) as StaffName, sr.TotalAmount, SUM(sri.Quantity) as TotalQuantity  FROM SalesReturn sr INNER JOIN SalesReturnItem sri ON sr.InvoiceNo = sri.InvoiceNo INNER JOIN Staff s ON s.StaffId = sr.userID WHERE convert(datetime,ReturnDate,103) BETWEEN convert(datetime,'" + startDate.ToShortDateString() + "',103) AND convert(datetime,'" + endDate.ToShortDateString() + "',103) AND sr.InvoiceNo LIKE '%" + txtName.Text + "%' GROUP BY sr.SalesReturnId, sr.ReturnDate, sr.InvoiceNo, sr.TotalAmount, s.lastname, s.firstname, s.MI ORDER BY ReturnDate, sr.InvoiceNo DESC";
                SQLConn.sql = "SELECT t.InvoiceNo, t.TDate, t.InvoiceNo, CONCAT(s.lastname, ', ', s.firstname, ' ', s.MI) as StaffName, " +
                                "t.TotalAmount, SUM(td.Quantity) as TotalQuantity, t.Status, t.transaction_type_id " +
                                "FROM transactions t INNER JOIN transactiondetails td ON t.InvoiceNo = td.InvoiceNo " +
                                "INNER JOIN Staff s ON s.StaffId = t.StaffId " +
                                "WHERE convert(datetime,TDate,103) BETWEEN convert(datetime,'" + startDate.ToShortDateString() + "',103) " +
                                "AND convert(datetime,'" + endDate.ToShortDateString() + "',103) " +
                                "GROUP BY t.InvoiceNo, t.TDate, t.InvoiceNo, t.TotalAmount, s.lastname, s.firstname, s.MI, t.Status, t.transaction_type_id " +
                                "ORDER BY TDate, t.InvoiceNo DESC;";

                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();
                ListView2.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["InvoiceNo"].ToString());
                    x.SubItems.Add(SQLConn.reader["TDate"].ToString());
                    x.SubItems.Add(SQLConn.reader["InvoiceNo"].ToString());
                    x.SubItems.Add(SQLConn.reader["StaffName"].ToString());
                    x.SubItems.Add(SQLConn.reader["TotalAmount"].ToString());
                    x.SubItems.Add(SQLConn.reader["TotalQuantity"].ToString());
                    x.SubItems.Add(GetTransactionStatus(Convert.ToInt32(SQLConn.reader["status"].ToString())));
                    x.SubItems.Add(GetTransactionTypeValue(Convert.ToInt32(SQLConn.reader["transaction_type_id"].ToString())));
                    //Strings.Format(SQLConn.reader["TotalAmount"], "#,##0.00")
                    ListView1.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        public void LoadingTransactionsByRBTN(DateTime startDate, DateTime endDate, int p_iTransactionStatus)
        {
            try
            {
                if (p_iTransactionStatus == 0 || p_iTransactionStatus == 1)
                //SQLConn.sql = "SELECT sr.SalesReturnId, sr.ReturnDate, sr.InvoiceNo, CONCAT(s.lastname, ', ', s.firstname, ' ', s.MI) as StaffName, sr.TotalAmount, SUM(sri.Quantity) as TotalQuantity  FROM SalesReturn sr INNER JOIN SalesReturnItem sri ON sr.InvoiceNo = sri.InvoiceNo INNER JOIN Staff s ON s.StaffId = sr.userID WHERE convert(datetime,ReturnDate,103) BETWEEN convert(datetime,'" + startDate.ToShortDateString() + "',103) AND convert(datetime,'" + endDate.ToShortDateString() + "',103) AND sr.InvoiceNo LIKE '%" + txtName.Text + "%' GROUP BY sr.SalesReturnId, sr.ReturnDate, sr.InvoiceNo, sr.TotalAmount, s.lastname, s.firstname, s.MI ORDER BY ReturnDate, sr.InvoiceNo DESC";
                    SQLConn.sql = "SELECT t.transactionid, t.TDate, t.transactionid, CONCAT(s.lastname, ', ', s.firstname, ' ', s.MI) as StaffName, " +
                                    "t.TotalAmount, SUM(td.Quantity) as TotalQuantity, t.Status, t.transaction_type_id " +
                                    "FROM transactions t INNER JOIN transactiondetails td ON t.transactionid = td.transactionid " +
                                    "INNER JOIN Staff s ON s.StaffId = t.StaffId " +
                                    "WHERE convert(datetime,TDate,103) BETWEEN convert(datetime,'" + startDate.ToShortDateString() + "',103) " +
                                    "AND convert(datetime,'" + endDate.ToShortDateString() + "',103) " +
                                    "AND  t.Status = " + p_iTransactionStatus +
                                    " GROUP BY t.transactionid, t.TDate, t.transactionid, t.TotalAmount, s.lastname, s.firstname, s.MI, t.Status, t.transaction_type_id " +
                                    "ORDER BY TDate, t.transactionid DESC;";
                else
                    SQLConn.sql = "SELECT t.transactionid, t.TDate, t.transactionid, CONCAT(s.lastname, ', ', s.firstname, ' ', s.MI) as StaffName, " +
                                    "t.TotalAmount, SUM(td.Quantity) as TotalQuantity, t.Status, t.transaction_type_id " +
                                    "FROM transactions t INNER JOIN transactiondetails td ON t.transactionid = td.transactionid " +
                                    "INNER JOIN Staff s ON s.StaffId = t.StaffId " +
                                    "WHERE convert(datetime,TDate,103) BETWEEN convert(datetime,'" + startDate.ToShortDateString() + "',103) " +
                                    "AND convert(datetime,'" + endDate.ToShortDateString() + "',103) " +
                                    " GROUP BY t.transactionid, t.TDate, t.transactionid, t.TotalAmount, s.lastname, s.firstname, s.MI, t.Status, t.transaction_type_id " +
                                    "ORDER BY TDate, t.transactionid DESC;";

                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();
                ListView2.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["transactionid"].ToString());
                    x.SubItems.Add(SQLConn.reader["TDate"].ToString());
                    x.SubItems.Add(SQLConn.reader["[transactionid"].ToString());
                    x.SubItems.Add(SQLConn.reader["StaffName"].ToString());
                    x.SubItems.Add(SQLConn.reader["TotalAmount"].ToString());
                    x.SubItems.Add(SQLConn.reader["TotalQuantity"].ToString());
                    x.SubItems.Add(GetTransactionStatus(Convert.ToInt32(SQLConn.reader["status"].ToString())));
                    x.SubItems.Add(GetTransactionTypeValue(Convert.ToInt32(SQLConn.reader["transaction_type_id"].ToString())));
                    //Strings.Format(SQLConn.reader["TotalAmount"], "#,##0.00")
                    ListView1.Items.Add(x);
                }

                ListView1.Columns[6].Width = 0;
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private string GetTransactionTypeValue(int p_iTransactionType)
        {
            string sTransactionType = "";

            if (p_iTransactionType == 0)
                sTransactionType = "ENTREE";

            if (p_iTransactionType == 1)
                sTransactionType = "SORTIE";

            if (p_iTransactionType == 2)
                sTransactionType = "RETOUR DE MARCHANDISES";

            return sTransactionType;
        }

        private string GetTransactionStatus(int p_iStatus)
        {
            string sTransactionStatus = "";

            if (p_iStatus == 0)
                sTransactionStatus = "VALIDEE";

            if (p_iStatus == 1)
                sTransactionStatus = "EN ATTENTE";

            return sTransactionStatus;
        }

        public void LoadTransactionItems(string invoiceNo)
        {
            try
            {
                SQLConn.sql = "SELECT p.ProductNo, p.Description, td.Quantity, p.UnitPrice, td.discount, (td.Quantity * p.UnitPrice - td.discount) ExtendedPrice FROM transactiondetails td INNER JOIN Product p ON p.ProductNo = td.ProductNo WHERE td.InvoiceNo = '" + invoiceNo + "' ORDER BY td.InvoiceNo desc ";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView2.Items.Clear();


                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["ProductNo"].ToString());
                    x.SubItems.Add(SQLConn.reader["Description"].ToString());
                    x.SubItems.Add(SQLConn.reader["Quantity"].ToString());
                    x.SubItems.Add(Strings.Format(SQLConn.reader["UnitPrice"], "#,##0.00"));
                    x.SubItems.Add(Strings.Format(SQLConn.reader["Discount"], "#,##0.00"));
                    x.SubItems.Add(Strings.Format(SQLConn.reader["ExtendedPrice"], "#,##0.00"));
                    //Strings.Format(SQLConn.reader["ExtendedPrice"], "#,##0.00")
                    ListView2.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        public void PrintSql_Array()
        {
            int[] numbers = new int[4];
            string[] names = new string[4];
            string[] secondNames = new string[4];
            int[] ages = new int[4];

            int cont = 0;

            string cs = @"Server=ADMIN\SQLEXPRESS; Database=dbYourBase; User id=sa; password=youpass";
            using (SqlConnection con = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT * FROM tbl_Datos";
                    con.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    foreach (DataRow row in dt.Rows)
                    {
                        numbers[cont] = row.Field<int>(0);
                        names[cont] = row.Field<string>(1);
                        secondNames[cont] = row.Field<string>(2);
                        ages[cont] = row.Field<int>(3);

                        cont++;
                    }

                    for (int i = 0; i < numbers.Length; i++)
                    {
                        Console.WriteLine("{0} | {1} {2} {3}", numbers[i], names[i], secondNames[i], ages[i]);
                    }

                    con.Close();
                }
            }
        }
        
        private void ValidateTransactionItems(string invoiceNo, string p_sTypeTransaction)
        {
            var listArticlesCanBeUpdated = new List<Tuple<string, string>>();
            var listArticlesCannotBeUpdated = new List<Tuple<string, string>>();
            var listArticles = new List<Tuple<string, string>>();

            SqlConnection mySqlConnection = new SqlConnection(SQLConn.connectionString);

            SqlCommand mySqlCommand = mySqlConnection.CreateCommand();

            mySqlCommand.CommandText =
              "SELECT productno, Quantity FROM transactiondetails WHERE InvoiceNo = '" + invoiceNo + "'";

            mySqlConnection.Open();

            SqlDataReader productsSqlDataReader = mySqlCommand.ExecuteReader();

            while (productsSqlDataReader.Read())
            {
                int Stock = 0;
                int ProductNo = productsSqlDataReader.GetOrdinal("ProductNo");
                int Quantity = productsSqlDataReader.GetOrdinal("Quantity");

                ProductNo = Convert.ToInt32(productsSqlDataReader[ProductNo]);
                Stock = Utility.GetProductStock(Convert.ToInt32(ProductNo));
                Quantity = Convert.ToInt32(productsSqlDataReader[Quantity]);

                if (p_sTypeTransaction == "SORTIE")
                {
                    if (Quantity > Stock)
                    {
                        MessageBox.Show("stock < quantity");
                        listArticlesCannotBeUpdated.Add(new Tuple<string, string>(ProductNo.ToString(), Quantity.ToString()));
                    }
                    else
                    {
                        MessageBox.Show("stock > quantity");
                        listArticlesCanBeUpdated.Add(new Tuple<string, string>(ProductNo.ToString(), Quantity.ToString()));
                    }
                }
                else
                    listArticles.Add(new Tuple<string, string>(ProductNo.ToString(), Quantity.ToString()));
            }


            if (listArticles.Count > 0)
            {
                foreach (var item in listArticles)
                {
                    MessageBox.Show("Item1 " + item.Item1 + " - Item2 : " + item.Item2);
                }
            }

            productsSqlDataReader.Close();
            mySqlConnection.Close();
        }

        private void ValidateTransactionItems2(string invoiceNo)
        {
            Dictionary<string, string> dictArticlesCanBeUpdated = new Dictionary<string, string>();
            Dictionary<float, int> dictArticlesCannotBeUpdated = new Dictionary<float, int>();
            var listArticlesCanBeUpdated = new List<Tuple<string, string>>();
            var listArticlesCannotBeUpdated = new List<Tuple<string, string>>();

            try
            {
                string sql = "SELECT productno, Quantity FROM transactiondetails WHERE InvoiceNo = '" + invoiceNo + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                while (SQLConn.reader.Read() == true)
                {
                    int stock = Utility.GetProductStock(Convert.ToInt32(SQLConn.reader["ProductNo"].ToString()));
                    int quantity = Convert.ToInt32(SQLConn.reader["ProductNo"].ToString());

                    if (stock > quantity)
                        MessageBox.Show("stock > quantity");

                    if (Utility.GetProductStock(Convert.ToInt32(SQLConn.reader["ProductNo"].ToString())) > Convert.ToInt32(SQLConn.reader["Quantity"].ToString()))
                        listArticlesCanBeUpdated.Add(new Tuple<string, string>(SQLConn.reader["ProductNo"].ToString(), SQLConn.reader["Quantity"].ToString()));
                    else
                        listArticlesCannotBeUpdated.Add(new Tuple<string, string>(SQLConn.reader["ProductNo"].ToString(), SQLConn.reader["Quantity"].ToString()));

                    //dictArticlesCanBeUpdated(SQLConn.reader["ProductNo"].ToString(), SQLConn.reader["ProductNo"].ToString());

                    //SQLConn.reader["Description"].ToString()
                    //SQLConn.reader["Quantity"].ToString()
                    //Strings.Format(SQLConn.reader["ExtendedPrice"], "#,##0.00")
                }

                if (listArticlesCannotBeUpdated.Count == 0)
                {
                    if (Interaction.MsgBox("Etes vous sûr de vouloir valider cette transaction?", MsgBoxStyle.YesNo, "Validation Transaction") == MsgBoxResult.Yes)
                    {

                    }
                }

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void frmListTransactions_Load(object sender, EventArgs e)
        {
            LoadingTransactionsByRBTN(dtStartDate.Value, dtEndDate.Value, 2);
        }

        private void dtStartDate_ValueChanged(object sender, EventArgs e)
        {
            Transactions(dtStartDate.Value, dtEndDate.Value, txtTransaction.Text);
        }

        private void dtEndDate_ValueChanged(object sender, EventArgs e)
        {
            Transactions(dtStartDate.Value, dtEndDate.Value, txtTransaction.Text);
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void ListView1_Click(object sender, EventArgs e)
        {
            try
            {
                LoadTransactionItems(ListView1.FocusedItem.SubItems[2].Text);
            }
            catch
            {

            }
        }

        private void ToolStripButton4_Click(object sender, EventArgs e)
        {
            
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ToolStripButton2_Click(object sender, EventArgs e)
        {
            Transactions(dtStartDate.Value, dtEndDate.Value, txtTransaction.Text);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            DisplayTransactions();
        }

        private void ListView1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                LoadTransactionItems(ListView1.FocusedItem.SubItems[2].Text);
            }
            catch
            {

            }
        }

        private void ListView1_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                LoadTransactionItems(ListView1.FocusedItem.SubItems[2].Text);
            }
            catch
            {

            }
        }

        private void picMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            /*if (Interaction.MsgBox("Êtes vous sûr de vouloir fermer cette fenêtre?", MsgBoxStyle.YesNo, "Liste des transactions") == MsgBoxResult.Yes)
            {
                //Application.Exit();
                this.Close();
            }*/
            this.Close();
        }

        private void txtTransaction_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtTransaction_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void rbtnAValider_CheckedChanged(object sender, EventArgs e)
        {
            LoadingTransactionsByRBTN(dtStartDate.Value, dtEndDate.Value, 1);
        }

        private void rbtnValide_CheckedChanged(object sender, EventArgs e)
        {
            LoadingTransactionsByRBTN(dtStartDate.Value, dtEndDate.Value, 0);
        }

        private void rbtnAllTransactions_CheckedChanged(object sender, EventArgs e)
        {
            LoadingTransactionsByRBTN(dtStartDate.Value, dtEndDate.Value, 2);
        }

        private void ListView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // Get the new sorting column.
            ColumnHeader new_sorting_column = ListView1.Columns[e.Column];

            // Figure out the new sorting order.
            System.Windows.Forms.SortOrder sort_order;
            if (Utility.SortingColumn == null)
            {
                // New column. Sort ascending.
                sort_order = System.Windows.Forms.SortOrder.Ascending;
            }
            else
            {
                // See if this is the same column.
                if (new_sorting_column == Utility.SortingColumn)
                {
                    // Same column. Switch the sort order.
                    if (Utility.SortingColumn.Text.StartsWith("> "))
                    {
                        sort_order = System.Windows.Forms.SortOrder.Descending;
                    }
                    else
                    {
                        sort_order = System.Windows.Forms.SortOrder.Ascending;
                    }
                }
                else
                {
                    // New column. Sort ascending.
                    sort_order = System.Windows.Forms.SortOrder.Ascending;
                }

                // Remove the old sort indicator.
                Utility.SortingColumn.Text = Utility.SortingColumn.Text.Substring(2);
            }

            // Display the new sort order.
            Utility.SortingColumn = new_sorting_column;
            if (sort_order == System.Windows.Forms.SortOrder.Ascending)
            {
                Utility.SortingColumn.Text = "> " + Utility.SortingColumn.Text;
            }
            else
            {
                Utility.SortingColumn.Text = "< " + Utility.SortingColumn.Text;
            }

            // Create a comparer.
            ListView1.ListViewItemSorter = new ListViewComparer(e.Column, sort_order);

            // Sort.
            ListView1.Sort();
        }

        private void validerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string typetransaction = ListView1.FocusedItem.SubItems[7].Text;
            //MessageBox.Show(ListView1.FocusedItem.SubItems[2].Text);
            ValidateTransactionItems(ListView1.FocusedItem.SubItems[2].Text, typetransaction);
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (ListView1.SelectedItems.Count == 0)
            {
                e.Cancel = true;
            }
        }

        string sTransactionStatus = "";
        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (ListView1.FocusedItem.Bounds.Contains(e.Location))
                {
                    //if (ListView1.FocusedItem.SubItems[6].Text == "EN ATTENTE")
                        contextMenuStrip1.Show(Cursor.Position);
                }
            }
        }

        SqlConnection con = new SqlConnection(SQLConn.connectionString);
        int transactionid = 0;

        private void supprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            transactionid = Convert.ToInt32(ListView1.SelectedItems[0].SubItems[2].Text);

            if (transactionid > 0)
            {
                //if (!Utility.isPartnerExistInProductTable(partnerid))
                //{
                SqlCommand cmd = new SqlCommand("delete from transactions where invoiceno = @invoiceno", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@invoiceno", this.transactionid);

                SqlCommand cmd1 = new SqlCommand("delete from transactiondetails where invoiceno = @invoiceno", con);
                cmd1.CommandType = CommandType.Text;
                cmd1.Parameters.AddWithValue("@invoiceno", this.transactionid);

                con.Open();
                cmd.ExecuteNonQuery();
                cmd1.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("La ligne sélectionnée a bien été supprimée.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadingTransactionsByRBTN(dtStartDate.Value, dtEndDate.Value, 2);
                LoadTransactionItems(SQLConn.strSearch.Trim());
                //}
                //else
                //MessageBox.Show("La ligne ne peut pas être supprimée car elle est liée à un produit.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Vous devez d'abord sélectionné une ligne.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnDeleteAllTransactions_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();

            DialogResult dialogResult = MessageBox.Show("Êtes-vous sûr(e) de vouloir supprimer toutes les transactions?", "Suppression de toutes les transactions", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                con.Open();
                try
                {
                    using (cmd = new SqlCommand("delete from transactiondetails", con))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                try
                {
                    using (cmd = new SqlCommand("delete from transactions", con))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                con.Close();

                LoadingTransactionsByRBTN(dtStartDate.Value, dtEndDate.Value, 2);
                LoadTransactionItems(SQLConn.strSearch.Trim());
            }
        }
    }
}
