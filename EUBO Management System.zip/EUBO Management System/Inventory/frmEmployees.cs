﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmEmployees : Form
    {
        public frmEmployees()
        {
            InitializeComponent();
        }

        SqlConnection sqlCon = new SqlConnection(SQLConn.connectionString);
        SqlCommandBuilder sqlCommand = null;
        SqlDataAdapter sqlAdapter = null;
        DataSet dataset = null;

        private void frmEmployees_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void dgvEmployee_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                int lastRow = dgvEmployee.Rows.Count - 2;
                DataGridViewRow nRow = dgvEmployee.Rows[lastRow];
                DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                dgvEmployee[6, lastRow] = linkCell;
                nRow.Cells["Delete"].Value = "Insert";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LoadData()
        {
            try
            {
                sqlAdapter = new SqlDataAdapter("SELECT *, 'Delete' AS [Delete] FROM Employees", sqlCon);
                sqlCommand = new SqlCommandBuilder(sqlAdapter);

                sqlAdapter.InsertCommand = sqlCommand.GetInsertCommand();
                sqlAdapter.UpdateCommand = sqlCommand.GetUpdateCommand();
                sqlAdapter.DeleteCommand = sqlCommand.GetDeleteCommand();

                dataset = new DataSet();
                sqlAdapter.Fill(dataset, "Employees");
                dgvEmployee.DataSource = null;
                dgvEmployee.DataSource = dataset.Tables["Employees"];

                for (int i = 0; i < dgvEmployee.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dgvEmployee[6, i] = linkCell;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvEmployee_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 6)
                {
                    string Task = dgvEmployee.Rows[e.RowIndex].Cells[6].Value.ToString();
                    if (Task == "Delete")
                    {
                        if (MessageBox.Show("Are you sure to delete?", "Deleting...", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;
                            dgvEmployee.Rows.RemoveAt(rowIndex);
                            dataset.Tables["Employees"].Rows[rowIndex].Delete();
                            sqlAdapter.Update(dataset, "Employees");
                        }
                    }
                    else if (Task == "Insert")
                    {
                        int row = dgvEmployee.Rows.Count - 2;
                        DataRow dr = dataset.Tables["Employees"].NewRow();
                        dr["LastName"] = dgvEmployee.Rows[row].Cells["LastName"].Value;
                        dr["FirstName"] = dgvEmployee.Rows[row].Cells["FirstName"].Value;
                        dr["Title"] = dgvEmployee.Rows[row].Cells["Title"].Value;
                        dr["HireDate"] = dgvEmployee.Rows[row].Cells["HireDate"].Value;
                        dr["PostalCode"] = dgvEmployee.Rows[row].Cells["PostalCode"].Value;

                        dataset.Tables["Employees"].Rows.Add(dr);
                        dataset.Tables["Employees"].Rows.RemoveAt(dataset.Tables["Employees"].Rows.Count - 1);
                        dgvEmployee.Rows.RemoveAt(dgvEmployee.Rows.Count - 2);
                        dgvEmployee.Rows[e.RowIndex].Cells[6].Value = "Delete";
                        sqlAdapter.Update(dataset, "Employees");
                    }
                    else if (Task == "Update")
                    {
                        int r = e.RowIndex;
                        dataset.Tables["Employees"].Rows[r]["LastName"] = dgvEmployee.Rows[r].Cells["LastName"].Value;
                        dataset.Tables["Employees"].Rows[r]["FirstName"] = dgvEmployee.Rows[r].Cells["FirstName"].Value;
                        dataset.Tables["Employees"].Rows[r]["Title"] = dgvEmployee.Rows[r].Cells["Title"].Value;
                        dataset.Tables["Employees"].Rows[r]["HireDate"] = dgvEmployee.Rows[r].Cells["HireDate"].Value;
                        dataset.Tables["Employees"].Rows[r]["PostalCode"] = dgvEmployee.Rows[r].Cells["PostalCode"].Value;
                        sqlAdapter.Update(dataset, "Employees");
                        dgvEmployee.Rows[e.RowIndex].Cells[6].Value = "Delete";
                    }
                }
            }
            catch (Exception ex) { }
        }
    }
}
