﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Linq;
using System.Drawing;

namespace EMS
{
    public partial class frmAddNewLicence1 : Form
    {
        int productID;
        int partnerID;
        bool bUpdateItem = false;

        public string ProductRef
        {
            get { return txtProductRef.Text; }
            set { txtProductRef.Text = value; }
        }

        public string ProductPrice
        {
            get { return txtProductPrice.Text; }
            set { txtProductPrice.Text = value; }
        }

        public string ProductStock
        {
            get { return txtProductStock.Text; }
            set { txtProductStock.Text = value; }
        }

        public string ProductQty
        {
            get { return txtProductQty.Text; }
            set { txtProductQty.Text = value; }
        }

        public string ProductDiscount
        {
            get { return txtProductDiscount.Text; }
            set { txtProductDiscount.Text = value; }
        }

        public string ProductAmount
        {
            get { return txtProductAmount.Text; }
            set { txtProductAmount.Text = value; }
        }

        public string Partner
        {
            get { return txtPartner.Text; }
            set { txtPartner.Text = value; }
        }

        public int PartnerID
        {
            get { return partnerID; }
            set { partnerID = value; }
        }

        public int ProductID
        {
            get { return productID; }
            set { productID = value; }
        }

        public frmAddNewLicence1()
        {
            InitializeComponent();
        }

        private void frmStockInOut_Load(object sender, EventArgs e)
        {
            cbxTransactionType.Items.Add("ENTREE");
            cbxTransactionType.Items.Add("SORTIE");
            cbxTransactionType.Items.Add("RETOUR DE MARCHANDISES");
           
            /*if (cbxTransactionType.SelectedIndex == -1)
            {
                cbxTransactionType.SelectedIndex = 0;
            }*/

            cbxTransactionType.SelectedIndex = 1;
            cbxTransactionType.SelectedIndexChanged -= new EventHandler(cbxTransactionType_SelectedIndexChanged);

            //lblFormTitleUser.Text = Utility.statffName.ToUpper() + " ) ";
            txtInvoiceNo.Text = Utility.GetNextInvoiceNo();
            txtStatus.Text = Utility.GetTransactionStatus(Convert.ToInt32(txtInvoiceNo.Text));
            EnableProductInfo();
            //SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
            Timer timer = new Timer();
            timer.Interval = 1000; // 10 secs
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();

            lvwAddedProducts.Columns[6].Width = 0;

        }

        private void timer_Tick(object sender, EventArgs e)
        {
            //EnableProductInfo();
        }

        private void dtStartDate_ValueChanged(object sender, EventArgs e)
        {
            //SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void dtEndDate_ValueChanged(object sender, EventArgs e)
        {
            //SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void ListView1_Click(object sender, EventArgs e)
        {/*
            try
            {
                LoadReturnItems(ListView1.FocusedItem.SubItems[2].Text);
            }
            catch
            {

            }*/
        }

        private void ToolStripButton4_Click(object sender, EventArgs e)
        {
            
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ToolStripButton2_Click(object sender, EventArgs e)
        {
            //SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            //SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void picMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            if (Interaction.MsgBox("Êtes vous sûr de vouloir quitter la transaction en cours (" + Utility.statffName.ToUpper() + ") ?", MsgBoxStyle.YesNo, "Transaction N° " + txtInvoiceNo.Text) == MsgBoxResult.Yes)
            {
                //Application.Exit();
                this.Close();
            }
        }

        private void frmStockInOut_MouseDown(object sender,System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Utility.ReleaseCapture();
                Utility.SendMessage(Handle, Utility.WM_NCLBUTTONDOWN, Utility.HT_CAPTION, 0);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void btnSelectProduct_Click(object sender, EventArgs e)
        {
            frmSelectProduct fsp = new frmSelectProduct(this, false);
            fsp.ShowDialog();
        }

        private void txtProductQty_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtProductQty.Text, "  ^ [0-9]"))
            {
                txtProductQty.Text = "";
                btnAdd.Enabled = false;
            }

            btnAdd.Enabled = true;
            CalculateProductPrice();
        }

        private void txtProductDiscount_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtProductDiscount.Text, "  ^ [0-9]"))
            {
                txtProductDiscount.Text = "";
                btnAdd.Enabled = false;
            }

            CalculateProductPrice();
        }

        private void txtProductQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                
            }

            CalculateProductPrice();
        }

        private void txtProductDiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }

            CalculateProductPrice();
        }

        private void CalculateProductPrice()
        {
            txtProductAmount.Text = "";
            double val1;
            double val2;
            double val3;

            bool validOne = Double.TryParse(txtProductPrice.Text, out val1);
            bool validTwo = Double.TryParse(txtProductDiscount.Text, out val2);
            bool validThree = Double.TryParse(txtProductQty.Text, out val3);

            if (validOne && validTwo && validThree || validOne && validThree)
            {
                if (validTwo.ToString() == "")
                    val2 = 0;

                double result = val1 * val3 - val2;
                txtProductAmount.Text = result.ToString();
            }
        }

        private void txtProductRef_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtProductRef.Text))
                txtProductRef.BackColor = Color.White;

            EnableProductInfo();
        }

        private void EnableProductInfo()
        {
            if (txtProductPrice.Text == "")
            {
                txtProductQty.Enabled = false;
                txtProductDiscount.Enabled = false;
            }
            else
            {
                txtProductQty.Enabled = true;
                txtProductDiscount.Enabled = true;
            }
        }

        private void txtProductQty_Leave(object sender, EventArgs e)
        {
            CalculateProductPrice();
        }

        private void txtProductDiscount_Leave(object sender, EventArgs e)
        {
            CalculateProductPrice();
        }

        private void btnSelectPartner_Click(object sender, EventArgs e)
        {
            frmSelectPartner fsp = new frmSelectPartner(this, false);
            fsp.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Utility.staffId.ToString());
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bUpdateItem = false;

            try
            {
                if (!String.IsNullOrEmpty(txtProductQty.Text))
                {
                    if (!String.IsNullOrEmpty(txtProductDiscount.Text))
                    {
                        if (Convert.ToDouble(txtProductDiscount.Text) < Convert.ToDouble(txtProductAmount.Text))
                            AddArticle();
                        else
                        {
                            txtProductDiscount.Text = "";
                            MessageBox.Show("La remise ne peut pas être supérieure au montant de l'article.");
                        }
                    }
                    else
                        AddArticle();
                }
                else
                    MessageBox.Show("La quantité ne peut pas être vide ou nulle.");
            }
            catch (Exception)
            {

            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lvwAddedProducts.Items.Count == 0)
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner un article", MsgBoxStyle.Exclamation, "Supprimer un article");
                return;
            }
            try
            {
                if (string.IsNullOrEmpty(lvwAddedProducts.FocusedItem.Text))
                {

                }
                else
                {
                    lvwAddedProducts.Items.Remove(lvwAddedProducts.SelectedItems[0]);
                    RefreshTotalAmount();
                }
            }
            catch
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner un article", MsgBoxStyle.Exclamation, "Supprimer un article");
                return;
            }

            ResetArticleInfo();
            lvwAddedProducts.Columns[6].Width = 0;
        }

        private void AddArticle()
        {
            try
            {
                ListViewItem lvi = new ListViewItem();
                string discount = string.IsNullOrEmpty(txtProductDiscount.Text) ? "0" : txtProductDiscount.Text;
                var txt = ProductID.ToString();

                if (!String.IsNullOrEmpty(txtProductRef.Text))
                {
                    if (!lvwAddedProducts.Items.ContainsKey(txt))
                    {
                        if (cbxTransactionType.SelectedIndex == 1)
                        {
                            if (Convert.ToInt32(txtProductQty.Text) > Convert.ToInt32(txtProductStock.Text))
                            {
                                txtProductQty.Text = "";
                                MessageBox.Show("La quantité disponible est insuffisante.");
                            }
                        }

                        if (Convert.ToInt32(txtProductQty.Text) >= 0)
                        {
                            lvi.Text = txt;
                            lvi.Name = txt;

                            lvi.SubItems.Add(txtProductRef.Text);
                            lvi.SubItems.Add(txtProductPrice.Text);
                            lvi.SubItems.Add(txtProductQty.Text);
                            lvi.SubItems.Add(discount);
                            lvi.SubItems.Add(txtProductAmount.Text);
                            lvi.SubItems.Add(txtProductStock.Text);
                            lvwAddedProducts.Items.Add(lvi);

                            RefreshTotalAmount();
                            ResetArticleInfo();
                            lvwAddedProducts.Columns[6].Width = 0;
                        }
                        else
                        {
                            txtProductQty.Text = "";
                            MessageBox.Show("La quantité saisie est invalide.");
                        }
                    }
                    else
                        MessageBox.Show("Le produit existe déjà.");
                }
                else
                {
                    txtProductRef.Focus();
                    txtProductRef.BackColor = Color.Red;
                    MessageBox.Show("Aucun article n'a été sélectionné.",
                    "Information",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation,
                    MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception)
            {
                //MessageBox.Show("La quantité ne peut pas ête nulle ou vide");
            }
        }

        private void lvwAddedProducts_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            /*txtProductRef.Text = lvwAddedProducts.SelectedItems[0].SubItems[0].Text;
            txtProductPrice.Text = lvwAddedProducts.SelectedItems[0].SubItems[2].Text;
            txtProductQty.Text = lvwAddedProducts.SelectedItems[0].SubItems[3].Text;
            txtProductDiscount.Text = lvwAddedProducts.SelectedItems[0].SubItems[4].Text;
            txtProductAmount.Text = lvwAddedProducts.SelectedItems[0].SubItems[5].Text;
            txtProductStock.Text = lvwAddedProducts.SelectedItems[0].SubItems[6].Text;*/
        }

        private void lvwAddedProducts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RefreshTotalAmount()
        {
            var sum = this.lvwAddedProducts.Items
            .Cast<ListViewItem>()
            .Sum(item => float.Parse(item.SubItems[5].Text));
            txtTransactionTotalAmount.Text = sum.ToString();
        }
    

        private void ResetArticleInfo()
        {
            txtProductRef.Focus();
            txtProductRef.Text = "";
            txtProductPrice.Text = "";
            txtProductStock.Text = "";
            txtProductQty.Text = "";
            txtProductDiscount.Text = "";
            txtProductAmount.Text = "";

            txtProductQty.Enabled = false;
            txtProductDiscount.Enabled = false;
        }

        private void lvwAddedProducts_MouseClick(object sender, MouseEventArgs e)
        {
            bUpdateItem = true;
            txtProductRef.Text = lvwAddedProducts.SelectedItems[0].SubItems[0].Text;
            txtProductPrice.Text = lvwAddedProducts.SelectedItems[0].SubItems[2].Text;
            txtProductStock.Text = lvwAddedProducts.SelectedItems[0].SubItems[6].Text;
            txtProductQty.Text = lvwAddedProducts.SelectedItems[0].SubItems[3].Text;
            txtProductDiscount.Text = lvwAddedProducts.SelectedItems[0].SubItems[4].Text;
            txtProductAmount.Text = lvwAddedProducts.SelectedItems[0].SubItems[5].Text;
            txtProductQty.Enabled = true;
            txtProductDiscount.Enabled = true;
        }

        private void txtProductQty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && bUpdateItem == true)
            {
                if (Convert.ToInt32(txtProductQty.Text) <= Convert.ToInt32(txtProductStock.Text))
                {
                    if (Convert.ToInt32(txtProductQty.Text) > 0)
                    {
                        UpdateListViewItem();
                        RefreshTotalAmount();
                        btnAdd.Enabled = false;
                    }
                    else
                        MessageBox.Show("La quantité saisie est invalide");
                }
                else
                    MessageBox.Show("La quantité disponible est insuffisante");
            }

        }

        private void UpdateListViewItem()
        {
            lvwAddedProducts.SelectedItems[0].SubItems[0].Text = txtProductRef.Text;
            lvwAddedProducts.SelectedItems[0].SubItems[2].Text = txtProductPrice.Text;
            lvwAddedProducts.SelectedItems[0].SubItems[6].Text = txtProductStock.Text;
            lvwAddedProducts.SelectedItems[0].SubItems[3].Text = txtProductQty.Text;
            lvwAddedProducts.SelectedItems[0].SubItems[4].Text = txtProductDiscount.Text;
            lvwAddedProducts.SelectedItems[0].SubItems[5].Text = txtProductAmount.Text;
            txtProductQty.Enabled = false;
            txtProductDiscount.Enabled = false;
        }

        private void txtProductDiscount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && bUpdateItem == true)
            {
                if (Convert.ToInt32(txtProductQty.Text) <= Convert.ToInt32(txtProductStock.Text))
                {
                    if (Convert.ToInt32(txtProductQty.Text) > 0)
                    {
                        UpdateListViewItem();
                        RefreshTotalAmount();
                        btnAdd.Enabled = false;
                    }
                    else
                    MessageBox.Show("La quantité saisie est invalide.",
                    "Information",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("La quantité disponible est insuffisante.",
                    "Information",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1);
            }
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            if (Utility.GetInvoiceNo(txtInvoiceNo.Text) == true)
                MessageBox.Show("La transaction : " + txtInvoiceNo.Text + " existe déjà.",
                "Transaction",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
            else
                ValidateTransaction(false, 0);
        }

        private void NewTransaction()
        {
            ResetArticleInfo();
            EnableProductInfo();
        }

        private void AddTransactionDetails()
        {
            SqlConnection con = new SqlConnection(SQLConn.connectionString);

            SqlCommand cmd = con.CreateCommand();

            cmd.Connection.Open();

            try
            {
                foreach (ListViewItem item in lvwAddedProducts.Items)
                {
                    cmd = con.CreateCommand();
                    cmd.Parameters.AddWithValue("@tdetailno", Utility.GetNextTransactionDetailsId());
                    cmd.Parameters.AddWithValue("@invoiceno", txtInvoiceNo.Text);
                    cmd.Parameters.AddWithValue("@productno", Convert.ToInt32(item.SubItems[0].Text));
                    cmd.Parameters.AddWithValue("@itemprice", Convert.ToDouble(item.SubItems[2].Text));
                    cmd.Parameters.AddWithValue("@quantity", item.SubItems[3].Text);
                    cmd.Parameters.AddWithValue("@discount", Convert.ToDouble(item.SubItems[4].Text));
                    cmd.Parameters.AddWithValue("@amount", Convert.ToDouble(item.SubItems[5].Text));
                    cmd.CommandText = "Insert Into transactiondetails(tdetailno,invoiceno,productno,itemprice,quantity,discount,amount) Values (@tdetailno,@invoiceno,@productno,@itemprice,@quantity,@discount,@amount)";
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                cmd.Connection.Close();
                cmd.Dispose();
            }
        }

        private void AddTransactionDetails2()
        {
            try
            {
                foreach (ListViewItem item in lvwAddedProducts.Items)
                {
                    SQLConn.sql = "Insert Into transactiondetails(tdetailno,invoiceno,productno,itemprice,quantity,discount,amount) Values (@tdetailno,@invoiceno,@productno,@itemprice,@quantity,@discount,@amount)";
                    SQLConn.ConnDB();
                    SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                    //cmd = con.CreateCommand();
                    SQLConn.command.Parameters.AddWithValue("@tdetailno", Utility.GetNextTransactionDetailsId());
                    SQLConn.command.Parameters.AddWithValue("@invoiceno", txtInvoiceNo.Text);
                    SQLConn.command.Parameters.AddWithValue("@productno", Convert.ToInt32(item.SubItems[0].Text));
                    SQLConn.command.Parameters.AddWithValue("@itemprice", Convert.ToDouble(item.SubItems[2].Text));
                    SQLConn.command.Parameters.AddWithValue("@quantity", item.SubItems[3].Text);
                    SQLConn.command.Parameters.AddWithValue("@discount", Convert.ToDouble(item.SubItems[4].Text));
                    SQLConn.command.Parameters.AddWithValue("@amount", Convert.ToDouble(item.SubItems[5].Text));
                    //cmd.CommandText = "Insert Into transactiondetails(tdetailno,invoiceno,productno,itemprice,quantity,discount,amount) Values (@tdetailno,@invoiceno,@productno,@itemprice,@quantity,@discount,@amount)";
                    
                    SQLConn.command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddTransaction(bool bLater)
        {
            int iStatus = 0;

            if (bLater == false)
                iStatus = 0;
            else
                iStatus = 1;

            DateTime datetime = DateTime.Now;

            SqlConnection con = new SqlConnection(SQLConn.connectionString);

            SqlCommand cmd = con.CreateCommand();

            cmd.Connection.Open();

            try
            {
                cmd = con.CreateCommand();
                cmd.Parameters.AddWithValue("@invoiceno", txtInvoiceNo.Text);
                cmd.Parameters.AddWithValue("@tdate", dtpTransactionDate.Value.ToShortDateString());
                cmd.Parameters.AddWithValue("@ttime", datetime.TimeOfDay.ToString());
                cmd.Parameters.AddWithValue("@nonvattotal", 0);
                cmd.Parameters.AddWithValue("@vatamount", 0);
                cmd.Parameters.AddWithValue("@totalamount", Convert.ToDecimal(txtTransactionTotalAmount.Text));
                cmd.Parameters.AddWithValue("@staffid", Utility.staffId);
                cmd.Parameters.AddWithValue("@status", iStatus);
                cmd.Parameters.AddWithValue("@transaction_type_id", cbxTransactionType.SelectedIndex);
                cmd.Parameters.AddWithValue("@transaction_discount", 0);
                cmd.Parameters.AddWithValue("@transaction_comments", txtComments.Text);
                cmd.CommandText = "insert into transactions(invoiceno,tdate,ttime,nonvattotal,vatamount,totalamount,staffid,status,transaction_type_id,transaction_discount,transaction_comments) Values (@invoiceno,@tdate,@ttime,@nonvattotal,@vatamount,@totalamount,@staffid,@status,@transaction_type_id,@transaction_discount,@transaction_comments)";
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                cmd.Connection.Close();
                cmd.Dispose();
            }
        }

        private void btnValidateLater_Click(object sender, EventArgs e)
        {
            if(Utility.GetInvoiceNo(txtInvoiceNo.Text) == true)
                MessageBox.Show("La transaction : " + txtInvoiceNo.Text + " existe déjà.",
                "Transaction",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
            else
                ValidateTransaction(true, 1);
        }

        private void ValidateTransaction (bool bLater, int p_iTransactionStatus)
        {
            if (lvwAddedProducts.Items.Count > 0 && txtPartner.Text != "")
            {
                AddTransactionDetails();

                if (bLater == true)
                {
                    AddTransaction(true);
                    UpdateProductStocks(cbxTransactionType.SelectedIndex, p_iTransactionStatus);
                }
                else
                {
                    AddTransaction(false);
                    UpdateProductStocks(cbxTransactionType.SelectedIndex, p_iTransactionStatus);
                }

                MessageBox.Show("Votre transaction a été enregistrée sous le numéro : " + txtInvoiceNo.Text + ".",
                "Transaction",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button1);
            }

            if (txtPartner.Text == "" && lvwAddedProducts.Items.Count > 0)
            {
                MessageBox.Show("Vous devez sélectionner un partenaire.",
                "Information",
                MessageBoxButtons.OK,
                MessageBoxIcon.Hand,
                MessageBoxDefaultButton.Button1);

                txtPartner.Focus();
                txtPartner.BackColor = Color.Red;
            }

            if (lvwAddedProducts.Items.Count == 0 && txtPartner.Text != "")
            {
                MessageBox.Show("Vous ne pouvez pas valider une transaction sans aucun article.",
                "Information",
                MessageBoxButtons.OK,
                MessageBoxIcon.Hand,
                MessageBoxDefaultButton.Button1);

                //txtPartner.Focus();
                //txtPartner.BackColor = Color.Red;
            }

            if (lvwAddedProducts.Items.Count == 0 && txtPartner.Text == "")
            {
                MessageBox.Show("Vous ne pouvez pas valider la transaction car elle est incomplète.",
                "Information",
                MessageBoxButtons.OK,
                MessageBoxIcon.Hand,
                MessageBoxDefaultButton.Button1);

                //txtPartner.Focus();
                //txtPartner.BackColor = Color.Red;
            }
        }

        private void txtPartner_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtPartner.Text))
                txtPartner.BackColor = Color.White;
        }

        private void btnNewTransaction_Click(object sender, EventArgs e)
        {
            if (Interaction.MsgBox("Êtes vous sûr de vouloir annuler la transaction en cours?", MsgBoxStyle.YesNo, "Nouvelle Transaction") == MsgBoxResult.Yes)
            {
                txtInvoiceNo.Text = Utility.GetNextInvoiceNo();
                txtStatus.Text = Utility.GetTransactionStatus(Convert.ToInt32(txtInvoiceNo.Text));
                txtPartner.Text = "";
                txtProductRef.Text = "";
                txtProductPrice.Text = "";
                txtProductStock.Text = "";
                txtProductQty.Text = "";
                txtProductDiscount.Text = "";
                txtProductAmount.Text = "";
                txtComments.Text = "";
                txtTransactionTotalAmount.Text = "";
                lvwAddedProducts.Items.Clear();
            }
        }

        private void btnModuleArticles_Click(object sender, EventArgs e)
        {
            frmListProduct lp = new frmListProduct();
            lp.ShowDialog();
        }

        private void UpdateProductStocks(int p_transaction_type, int p_iTransactionStatus)
        {
            int iTransactionSatuts = 0;

            if (p_iTransactionStatus == 0)
                iTransactionSatuts = 0;
            else
                iTransactionSatuts = 1;

            try
            {
                if (p_transaction_type == 0 || p_transaction_type == 2)
                {
                    foreach (ListViewItem item in lvwAddedProducts.Items)
                    {
                        Utility.AddStockIn(Convert.ToInt32(item.SubItems[0].Text), item.SubItems[3].Text, p_transaction_type, iTransactionSatuts);
                        //Utility.UpdateProductQuantity(item.SubItems[3].Text, Convert.ToInt32(item.SubItems[0].Text), p_transaction_type);
                    }
                }

                if (p_transaction_type == 1)
                {
                    foreach (ListViewItem item in lvwAddedProducts.Items)
                    {
                        Utility.AddStockOut(Convert.ToInt32(item.SubItems[0].Text), item.SubItems[3].Text, p_transaction_type, iTransactionSatuts);
                        //Utility.UpdateProductQuantity(item.SubItems[3].Text, Convert.ToInt32(item.SubItems[0].Text), p_transaction_type);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void cbxTransactionType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbxTransactionType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Etes-vous sûr de vouloir changer le type de transaction?",
            "Type de transaction",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button1);
            if (dialogResult == DialogResult.Yes)
            {
                lvwAddedProducts.Items.Clear();
            }
            else if (dialogResult == DialogResult.No)
            {
                //do something else
            }
        }

        private void btnAllTransactions_Click(object sender, EventArgs e)
        {
            frmAllTransactions frm = new frmAllTransactions();
            frm.Show();
        }

        private void txtProductPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
