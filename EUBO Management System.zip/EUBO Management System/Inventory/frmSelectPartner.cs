﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmSelectPartner : Form
    {
        private frmAddNewLicence1 frmProduct = null;
        private frmAddProductQuick frmProductQuick = null;
        bool IsQuickAdd;
        public frmSelectPartner(Form callingForm, bool isQuickAdd)
        {
            InitializeComponent();

            if (isQuickAdd != true)
            {
                frmProduct = callingForm as frmAddNewLicence1;
            }
            else
            {
                frmProductQuick = callingForm as frmAddProductQuick;
            }
            
            
            IsQuickAdd = isQuickAdd;
        }

        private void LoadPartner()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM partner WHERE partner_name LIKE '" + txtPartnerName.Text + "%' ORDER BY partner_id desc";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["partner_id"].ToString());
                    x.SubItems.Add(SQLConn.reader["partner_name"].ToString());
                    x.SubItems.Add(SQLConn.reader["partner_description"].ToString());

                    ListView1.Items.Add(x);
                }

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmSelectPartner_Load(object sender, EventArgs e)
        {
            LoadPartner();
        }

        private void ListView1_DoubleClick(object sender, EventArgs e)
        {

            int id = Convert.ToInt32(ListView1.FocusedItem.Text);

            if (IsQuickAdd != true)
            {
                this.frmProduct.PartnerID = id;
                this.frmProduct.Partner = ListView1.FocusedItem.SubItems[1].Text;
            }
            else
            {
                this.frmProductQuick.MeasureunitID = id;
                this.frmProductQuick.MeasureUnit = ListView1.FocusedItem.SubItems[1].Text;
            }
           
            this.Close();
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtUM_TextChanged(object sender, EventArgs e)
        {
            LoadPartner();
        }
    }
}
