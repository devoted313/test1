﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmReportStocksOut : Form
    {
        DateTime StartDate;
        DateTime EndDate;

        public frmReportStocksOut(DateTime startDate, DateTime endDate)
        {
            InitializeComponent();

            StartDate = startDate;
            EndDate = endDate;
        }

        private void frmReportStocksOut_Load(object sender, EventArgs e)
        {

            LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                if (InvoiceSetting() == 1)
                {
                    SQLConn.sql = "SELECT P.ProductCode, P.Description, T.TDate as DateOut, SUM(TD.Quantity) as Quantity, TD.ItemPrice as Price, (SUM(TD.Quantity) * TD.ItemPrice) as TotalAmount FROM Product as P, Transactions as T, TransactionDetails as TD WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND convert(datetime,TDate,103) BETWEEN convert(datetime, '" + StartDate.ToShortDateString()+ "', 103) AND convert(datetime, '" + EndDate.ToShortDateString() + "', 103) AND T.Status != 1 GROUP BY P.ProductCode, P.Description, T.TDate, TD.ItemPrice, TD.Quantity ORDER By T.TDate, P.Description";
                }
                else
                {
                    SQLConn.sql = "SELECT P.ProductCode, P.Description, T.TDate as DateOut, SUM(TD.Quantity) as Quantity, TD.ItemPrice as Price, (SUM(TD.Quantity) * TD.ItemPrice) as TotalAmount FROM Product as P, Transactions as T, TransactionDetails as TD WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND convert(datetime,TDate,103) BETWEEN convert(datetime, '" + StartDate.ToShortDateString() + "', 103) AND convert(datetime, '" + EndDate.ToShortDateString() + "', 103) GROUP BY P.ProductCode, P.Description, T.TDate, TD.ItemPrice, TD.Quantity ORDER By T.TDate, P.Description";
                }
                
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.da = new SqlDataAdapter(SQLConn.command);

                this.dsReportC.StocksOut.Clear();
                SQLConn.da.Fill(this.dsReportC.StocksOut);

                ReportParameter startDate = new ReportParameter("StartDate", StartDate.ToString());
                ReportParameter endDate = new ReportParameter("EndDate", EndDate.ToString());

                this.reportViewer1.LocalReport.SetParameters(new ReportParameter[] { startDate, endDate });

                this.reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
                this.reportViewer1.ZoomPercent = 90;
                this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.Percent;

                this.reportViewer1.RefreshReport();

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
        }

        int InvoiceSetting()
        {
            int ret = 0;
            try
            {
                SQLConn.sql = "SELECT HInvoice FROM Company";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();


                if (SQLConn.reader.Read() == true)
                {
                    ret = Convert.ToInt32(SQLConn.reader["HInvoice"]);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }

            return ret;
        }
    }
}
