﻿namespace EMS
{


    public partial class dsReportC
    {
    }
}
namespace EMS {
    
    
    public partial class dsReportC {
    }
}
