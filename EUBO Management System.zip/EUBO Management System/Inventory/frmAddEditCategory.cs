﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmAddEditCategory : Form
    {
        int categoryID;
        public frmAddEditCategory(int catID)
        {
            InitializeComponent();

            categoryID = catID;
        }

        private void LoadUpdateCategory()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM Category WHERE CategoryNo = '" + categoryID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    txtCategoryID.Text = SQLConn.reader["CategoryNo"].ToString();
                    txtCategoryName.Text = SQLConn.reader["CategoryName"].ToString();
                    txtCategoryDescription.Text = SQLConn.reader["Description"].ToString();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddCategory()
        {
            try
            {
                SQLConn.sql = "INSERT INTO Category(CategoryNo, CategoryName, Description) VALUES('" + Utility.GetCategoryNo() + "', '" + txtCategoryName.Text + "', '" + txtCategoryDescription.Text + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Nouvelle catégorie ajoutée avec succès.", MsgBoxStyle.Information, "Ajout d'une catégorie");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void UpdateCategory()
        {
            try
            {
                SQLConn.sql = "UPDATE Category SET CategoryName= '" + txtCategoryName.Text + "', Description = '" + txtCategoryDescription.Text + "' WHERE CategoryNo = '" + categoryID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Mise à jour effectuée avec succès.", MsgBoxStyle.Information, "Mise à jour d'une catégorie");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void CLearFields()
        {
            txtCategoryID.Text = "";
            txtCategoryName.Text = "";
            txtCategoryDescription.Text = "";
        }

        private void frmAddEditCategory_Load(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                lblTitle.Text = "Ajout d'une nouvelle catégorie";
                CLearFields();
                txtCategoryID.Text = Utility.GetCategoryNo();
            }
            else
            {
                lblTitle.Text = "Mise à jour d'une catégorie";
                LoadUpdateCategory();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                AddCategory();
            }
            else
            {
                UpdateCategory();
               
            }
            if (System.Windows.Forms.Application.OpenForms["frmListCategory"] != null)
            {
                (System.Windows.Forms.Application.OpenForms["frmListCategory"] as frmListCategory).LoadCategories("");
            }

            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
