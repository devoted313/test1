﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmAddEditStaff : Form
    {
        int LSStaffID;
        public frmAddEditStaff(int staffID)
        {
            
            InitializeComponent();
            LSStaffID = staffID;
        }

     
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                AddStaff();
            }
            else
            {
                UpdateStaff();
            }

            if (System.Windows.Forms.Application.OpenForms["frmListStaff"] != null)
            {
                (System.Windows.Forms.Application.OpenForms["frmListStaff"] as frmListStaff).LoadStaffs("");
            }

            this.Close();
        }

        private void GetStaffID()
        {
            try
            {
                SQLConn.sql = "SELECT StaffID FROM STAFF ORDER BY StaffID DESC";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    lblProductNo.Text = (Convert.ToInt32(SQLConn.reader["StaffID"]) + 1).ToString();
                }
                else
                {
                    lblProductNo.Text = "1";
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddStaff()
        {
            try
            {
                SQLConn.sql = "INSERT INTO STAFF(StaffID, Lastname, Firstname, MI, Street, Barangay, City, Province, ContactNo, Username, Role, UPassword) VALUES('" + Utility.GetStaffID() + "', '" +  txtLastname.Text + "', '" + txtFirstname.Text + "', '" + txtMI.Text + "', '" + txtStreet.Text + "', '" + txtBarangay.Text + "', '" + txtCity.Text + "', '" + txtProvince.Text + "', '" + txtContractNo.Text + "', '" + txtUsername.Text + "', '" + cbxRole.Text + "', '" + txtPassword.Text + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Nouvel utilisateur ajouté avec succès.", MsgBoxStyle.Information, "Ajout d'un utilisateur");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void UpdateStaff()
        {
            try
            {
                SQLConn.sql = "Update STAFF SET Lastname = '" + txtLastname.Text + "', Firstname = '" + txtFirstname.Text + "', MI = '" + txtMI.Text + "', Street= '" + txtStreet.Text + "', Barangay = '" + txtBarangay.Text + "', City = '" + txtCity.Text + "', Province = '" + txtProvince.Text + "', ContactNo = '" + txtContractNo.Text + "', Username ='" + txtUsername.Text + "', Role = '" + cbxRole.Text + "', UPassword = '" + txtPassword.Text + "' WHERE StaffID = '" + LSStaffID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Utilisateur modifié avec succès.", MsgBoxStyle.Information, "Mise à jour d'un utilisateur");

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void LoadUpdateStaff()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM STAFF WHERE StaffID = '" + LSStaffID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    lblProductNo.Text = SQLConn.reader["StaffID"].ToString();
                    txtLastname.Text = SQLConn.reader["lastname"].ToString();
                    txtFirstname.Text = SQLConn.reader["Firstname"].ToString();
                    txtMI.Text = SQLConn.reader["MI"].ToString();
                    txtStreet.Text = SQLConn.reader["Street"].ToString();
                    txtBarangay.Text = SQLConn.reader["barangay"].ToString();
                    txtCity.Text = SQLConn.reader["City"].ToString();
                    txtProvince.Text = SQLConn.reader["Province"].ToString();
                    txtContractNo.Text = SQLConn.reader["ContactNo"].ToString();
                    txtUsername.Text = SQLConn.reader["username"].ToString();
                    cbxRole.Text = SQLConn.reader["Role"].ToString();
                    txtPassword.Text = SQLConn.reader["UPassword"].ToString();
                    txtConfirmPWD.Text = SQLConn.reader["UPassword"].ToString();

                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void ClearFields()
        {
            lblProductNo.Text = "";
            txtLastname.Text = "";
            txtFirstname.Text = "";
            txtMI.Text = "";
            txtStreet.Text = "";
            txtBarangay.Text = "";
            txtCity.Text = "";
            txtProvince.Text = "";
            txtContractNo.Text = "";
            txtUsername.Text = "";
            cbxRole.Text = "";
            txtPassword.Text = "";
            txtConfirmPWD.Text = "";
        }

        private void frmAddEditStaff_Load(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                lblTitle.Text = "Ajout d'un nouvel utilisateur";
                ClearFields();
                GetStaffID();
            }
            else
            {
                lblTitle.Text = "Mise à jour d'un utilisateur";
                LoadUpdateStaff();
            }


            if (cbxRole.SelectedIndex == -1)
            {
                cbxRole.SelectedIndex = 0;
            }
        }
    }
}
