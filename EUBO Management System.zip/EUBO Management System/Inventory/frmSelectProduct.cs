﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmSelectProduct : Form
    {
        private frmAddNewLicence1 frmStockInOut = null;
        private frmAddProductQuick frmProductQuick = null;
        bool IsQuickAdd;
        public frmSelectProduct(Form callingForm, bool isQuickAdd)
        {
            InitializeComponent();

            if (isQuickAdd != true)
            {
                frmStockInOut = callingForm as frmAddNewLicence1;
            }
            else
            {
                frmProductQuick = callingForm as frmAddProductQuick;
            }
            
            
            IsQuickAdd = isQuickAdd;
        }

        private void LoadProduct()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM product WHERE description LIKE '%" + txtProduct.Text + "%' OR ProductCOde LIKE '%" + txtProduct.Text + "%' ORDER BY ProductNo desc";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["ProductNo"].ToString());
                    x.SubItems.Add(SQLConn.reader["ProductCode"].ToString());
                    x.SubItems.Add(SQLConn.reader["Description"].ToString());
                    x.SubItems.Add(SQLConn.reader["UnitPrice"].ToString());
                    x.SubItems.Add(SQLConn.reader["StocksOnHand"].ToString());
                    ListView1.Items.Add(x);
                }

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmSelectCategory_Load(object sender, EventArgs e)
        {
            LoadProduct();
        }

        private void txtProduct_TextChanged(object sender, EventArgs e)
        {
            LoadProduct();
        }

        private void ListView1_DoubleClick(object sender, EventArgs e)
        {

            int id = Convert.ToInt32(ListView1.FocusedItem.Text);

            if (IsQuickAdd != true)
            {
                this.frmStockInOut.ProductID = id;
                this.frmStockInOut.ProductRef = ListView1.FocusedItem.SubItems[2].Text;
                this.frmStockInOut.ProductPrice = ListView1.FocusedItem.SubItems[3].Text;
                this.frmStockInOut.ProductStock = ListView1.FocusedItem.SubItems[4].Text;
                this.frmStockInOut.ProductDiscount = "";
                this.frmStockInOut.ProductQty = "";
                this.frmStockInOut.txtProductQty.Enabled = true;
                this.frmStockInOut.txtProductDiscount.Enabled = true;
            }
            else
            {
                this.frmProductQuick.CategoryID = id;
                this.frmProductQuick.Category = ListView1.FocusedItem.SubItems[1].Text;
            }
           
            this.Close();
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
