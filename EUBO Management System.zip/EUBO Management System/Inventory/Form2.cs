﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(SQLConn.connectionString);
        public int StudentID;

        private void Form2_Load(object sender, EventArgs e)
        {
            GetStudentsRecord();
            //dataGridView1_CellClick(dataGridView1, new DataGridViewCellEventArgs(0, 0));
        }

        private void GetStudentsRecord()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select * from studentstb", con);
                DataTable dt = new DataTable();

                con.Open();

                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                con.Close();

                dataGridView1.DataSource = dt;
                dataGridView1.Rows[0].Selected = false;
            }
            catch (Exception)
            {
            }
        }

        private bool IsValid()
        {
            if(txtStudentName.Text == string.Empty)
            {
                MessageBox.Show("Student Name is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if(IsValid())
            {
                SqlCommand cmd = new SqlCommand("insert into studentstb values (@name, @fathername, @roll, @address, @mobile)", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@name", txtStudentName.Text);
                cmd.Parameters.AddWithValue("@fathername", txtFatherName.Text);
                cmd.Parameters.AddWithValue("@roll", txtRollNumber.Text);
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@mobile", txtMobile.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("New student is successfully saved in the database", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetStudentsRecord();
                ResetFormControls();
            }
        }

        private void ResetFormControls()
        {
            txtStudentName.Clear();
            txtFatherName.Clear();
            txtRollNumber.Clear();
            txtMobile.Clear();
            txtAddress.Clear();

            txtStudentName.Focus();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetFormControls();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                StudentID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                txtStudentName.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                txtFatherName.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                txtRollNumber.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                txtAddress.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                txtMobile.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            }
            catch (Exception)
            {
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if(StudentID > 0)
            {
                SqlCommand cmd = new SqlCommand("update studentstb set name=@name, fathername=@fathername, rollnumber=@roll, address=@address, mobile=@mobile where studentid = @id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@name", txtStudentName.Text);
                cmd.Parameters.AddWithValue("@fathername", txtFatherName.Text);
                cmd.Parameters.AddWithValue("@roll", txtRollNumber.Text);
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@mobile", txtMobile.Text);
                cmd.Parameters.AddWithValue("@id", this.StudentID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Student information is updated successfully saved in the database", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetStudentsRecord();
                ResetFormControls();
            }
            else
            {
                MessageBox.Show("Please select a Student to update his information", "Select", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (StudentID > 0)
            {
                SqlCommand cmd = new SqlCommand("delete from studentstb where studentid = @id", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@id", this.StudentID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Student is deleted from the system", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetStudentsRecord();
                ResetFormControls();
            }
            else
            {
                MessageBox.Show("Please select a Student to delete", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
