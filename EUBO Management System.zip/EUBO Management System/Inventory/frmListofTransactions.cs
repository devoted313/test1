﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmListofTransactions : Form
    {
     //   private frmReturn frmReturn = null;
        public frmListofTransactions(Form callForm)
        {
            InitializeComponent();
          //  frmReturn = callForm as frmReturn;
           
        }

        private void LoadInvoices(DateTime startDate, DateTime endDate, string searchString)
        {
           
            try
            {
                SQLConn.sql = "SELECT TDate, InvoiceNo, CONCAT(lastname, ', ', firstname, ' ', MI) as StaffName FROM Transactions T INNER JOIN staff S ON T.StaffID = S.StaffID WHERE BETWEEN '" + startDate.ToShortDateString() + "' AND '" + endDate.ToShortDateString() + "' AND InvoiceNo LIKE '%" + txtName.Text + "%' ORDER BY TDATE, InvoiceNo Desc";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(Strings.Format(SQLConn.reader["TDate"], "dd/MM/yyyy"));
                    x.SubItems.Add(SQLConn.reader["InvoiceNo"].ToString());
                    x.SubItems.Add(SQLConn.reader["StaffName"].ToString());
                   
                    ListView1.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void frmListofTransactions_Load(object sender, EventArgs e)
        {
            LoadInvoices(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            LoadInvoices(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtStartDate_ValueChanged(object sender, EventArgs e)
        {
            LoadInvoices(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void dtEndDate_ValueChanged(object sender, EventArgs e)
        {
            LoadInvoices(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
                      
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
              
                this.Close();
            }
            catch { }
        }

        private void ListView1_DoubleClick(object sender, EventArgs e)
        {
            try
            {
              
            }
            catch { }
        }

    }
}
