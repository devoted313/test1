﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using LVWComparer;
using System.Drawing;
using System.Data;

namespace EMS
{
    public partial class frmListProduct : Form
    {
        int productID;
        int categoryID;
        int measureUnitID;

        public frmListProduct()
        {
            InitializeComponent();
        }

        public void LoadProducts(string search)
        {
            try
            {
                SQLConn.sql = "SELECT ProductNo, ProductCOde, P.Description, Barcode, UnitPrice, StocksOnHand, ReorderLevel, CategoryName, c.categoryno, measure_unit_name, m.measure_unit_id FROM Product as P LEFT JOIN Category C ON P.CategoryNo = C.CategoryNo LEFT JOIN measure_unit m on p.measure_unit_id = m.measure_unit_id order by ProductNo desc"; // WHERE P.Description LIKE  @Description OR P.Barcode LIKE @Barcode ORDER BY Description";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                //SQLConn.command.Parameters.AddWithValue("@Description", "%" + strSearch + "%");
                //SQLConn.command.Parameters.AddWithValue("@Barcode", "%" + strSearch + "%");
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();


                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["ProductNo"].ToString());
                    //x.SubItems.Add(SQLConn.reader["ProductCode"].ToString());
                    x.SubItems.Add(SQLConn.reader["Description"].ToString());
                    //x.SubItems.Add(SQLConn.reader["Barcode"].ToString());
                    x.SubItems.Add(SQLConn.reader["categoryno"].ToString());
                    x.SubItems.Add(SQLConn.reader["CategoryName"].ToString());
                    x.SubItems.Add(SQLConn.reader["measure_unit_id"].ToString());
                    x.SubItems.Add(SQLConn.reader["measure_unit_name"].ToString());
                    x.SubItems.Add(Strings.Format(SQLConn.reader["UnitPrice"], "#,##0.00"));
                    x.SubItems.Add(SQLConn.reader["StocksOnHand"].ToString());
                    //x.SubItems.Add(SQLConn.reader["ReOrderLevel"].ToString());

                    ListView1.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            SQLConn.adding = true;
            SQLConn.updating = false;
            int init = 0;
            frmAddEditProduct aeP = new frmAddEditProduct(init, init, init);
            aeP.ShowDialog();
        }

        private void Modifier()
        {
            try
            {
                SQLConn.adding = false;
                SQLConn.updating = true;
                productID = Convert.ToInt32(ListView1.FocusedItem.Text);

                string categorydesc = ListView1.SelectedItems[0].SubItems[3].Text;
                string measuredesc = ListView1.SelectedItems[0].SubItems[5].Text;

                if (categorydesc == "")
                    categoryID = 0;
                else
                    categoryID = Convert.ToInt32(ListView1.SelectedItems[0].SubItems[2].Text);

                if (measuredesc == "")
                    measureUnitID = 0;
                else
                    measureUnitID = Convert.ToInt32(ListView1.SelectedItems[0].SubItems[4].Text);

                frmAddEditProduct aeP = new frmAddEditProduct(productID, categoryID, measureUnitID);
                aeP.ShowDialog();
            }
            catch (Exception)
            {

            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ListView1.Items.Count == 0)
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner une ligne.", MsgBoxStyle.Exclamation, "Mise à jour");
                return;
            }
            try
            {
                if (string.IsNullOrEmpty(ListView1.FocusedItem.Text))
                {

                }
                else
                {
                    SQLConn.adding = false;
                    SQLConn.updating = true;
                    productID = Convert.ToInt32(ListView1.FocusedItem.Text);
                    categoryID = Convert.ToInt32(ListView1.SelectedItems[0].SubItems[2].Text);
                    measureUnitID = Convert.ToInt32(ListView1.SelectedItems[0].SubItems[4].Text);
                    frmAddEditProduct aeP = new frmAddEditProduct(productID, categoryID, measureUnitID);
                    aeP.ShowDialog();
                }
            }
            catch
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner une ligne.", MsgBoxStyle.Exclamation, "Mise à jour");
                return;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SQLConn.strSearch = Interaction.InputBox("ENTER PRODUCT NAME OR BARCODE.", "Search Product", " ");

            if (SQLConn.strSearch.Length >= 1)
            {
                LoadProducts(SQLConn.strSearch.Trim());
            }
            else if (string.IsNullOrEmpty(SQLConn.strSearch))
            {
                return;
            }
        }

        private void frmListProduct_Load(object sender, EventArgs e)
        {
            LoadProducts("");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnStocksIn_Click(object sender, EventArgs e)
        {
            if (ListView1.Items.Count == 0)
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner un article", MsgBoxStyle.Exclamation, "Entrée de stock");
                return;
            }
            try
            {
                if (string.IsNullOrEmpty(ListView1.FocusedItem.Text))
                {

                }
                else
                {
                    productID = Convert.ToInt32(ListView1.FocusedItem.Text);
                    frmListProductStocksIn aeP = new frmListProductStocksIn(productID);
                    aeP.ShowDialog();
                }
            }
            catch
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner un article", MsgBoxStyle.Exclamation, "Entrée de stock");
                return;
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            frmImportProduct ip = new frmImportProduct();
            ip.ShowDialog();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            DisplayProducts();
        }

        private void DisplayProducts()
        {
            // prevent flickering
            ListView1.BeginUpdate();

            // restore all items in case user deletes some characters in the textbox
            //ReinitList();

            string search = txtSearch.Text;

            LoadProducts(search);

            // Search items in our Jobs ListView, remove those that do not match search
            if (search != String.Empty)
            {
                //LoadProducts(search);

                for (int i = ListView1.Items.Count - 1; i >= 0; i--)
                {
                    ListViewItem currentItem = ListView1.Items[i];
                    if (Utility.ItemMatches(currentItem, search))
                    {
                        // highlight, or move highlighting to ItemMatches
                    }
                    else
                    {
                        ListView1.Items.RemoveAt(i);
                    }
                }
            }
            else
                LoadProducts(search);

            ListView1.EndUpdate();
        }

        private void ListView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // Get the new sorting column.
            ColumnHeader new_sorting_column = ListView1.Columns[e.Column];

            // Figure out the new sorting order.
            System.Windows.Forms.SortOrder sort_order;
            if (Utility.SortingColumn == null)
            {
                // New column. Sort ascending.
                sort_order = System.Windows.Forms.SortOrder.Ascending;
            }
            else
            {
                // See if this is the same column.
                if (new_sorting_column == Utility.SortingColumn)
                {
                    // Same column. Switch the sort order.
                    if (Utility.SortingColumn.Text.StartsWith("> "))
                    {
                        sort_order = System.Windows.Forms.SortOrder.Descending;
                    }
                    else
                    {
                        sort_order = System.Windows.Forms.SortOrder.Ascending;
                    }
                }
                else
                {
                    // New column. Sort ascending.
                    sort_order = System.Windows.Forms.SortOrder.Ascending;
                }

                // Remove the old sort indicator.
                Utility.SortingColumn.Text = Utility.SortingColumn.Text.Substring(2);
            }

            // Display the new sort order.
            Utility.SortingColumn = new_sorting_column;
            if (sort_order == System.Windows.Forms.SortOrder.Ascending)
            {
                Utility.SortingColumn.Text = "> " + Utility.SortingColumn.Text;
            }
            else
            {
                Utility.SortingColumn.Text = "< " + Utility.SortingColumn.Text;
            }

            // Create a comparer.
            ListView1.ListViewItemSorter = new ListViewComparer(e.Column, sort_order);

            // Sort.
            ListView1.Sort();
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                DisplayProducts();
        }

        private void ListView1_DoubleClick(object sender, EventArgs e)
        {
            Modifier();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (ListView1.SelectedItems.Count == 0)
            {
                e.Cancel = true;
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ListView1.SelectedItems.Count > 0)
            {
                Modifier();
            }
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (ListView1.FocusedItem.Bounds.Contains(e.Location))
                {
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                DisplayProducts();
            }
        }

        SqlConnection con = new SqlConnection(SQLConn.connectionString);
        int productno = 0;

        private void supprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {

            productno = Convert.ToInt32(ListView1.FocusedItem.Text);

            if (productno > 0)
            {
                //if (!Utility.isProductExistInStockInTable(productno) || !Utility.isProductExistInStockOutTable(productno) || !Utility.isProductExistInTransactionDetailsTable(productno))
                //{
                    SqlCommand cmd = new SqlCommand("delete from product where productno = @productno", con);
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@productno", this.productno);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("La ligne sélectionnée a bien été supprimée.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisplayProducts();
                //}
                //else
                    //MessageBox.Show("La ligne ne peut pas être supprimée car elle est référencée dans d'autres tables.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Vous devez d'abord sélectionné une ligne.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
}
