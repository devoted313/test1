﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmEnterPassword : Form
    {
      //  frmPOS POSForm;
        public frmEnterPassword()
        {
            InitializeComponent();
          //  POSForm = pos;
        }

        private void button4_Click(object sender, EventArgs e)
        {
       //     this.POSForm.IsPasswordCancel = true;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
      //      this.POSForm.IsPasswordCorrect = IsPasswordCorrect();
            this.Close();
        }

        private bool IsPasswordCorrect()
        {
            bool ret = false;

            try
            {
                SQLConn.sql = "SELECT * FROM Staff WHERE Role ='Admin' AND UPassword = '" + txtAdminPassword.Text + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    ret = true;
                }
              
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }

            return ret;
        }

        private void txtAdminPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnOkay.PerformClick();
            }
        }

       
    }
}
