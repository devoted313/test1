﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmListReturns : Form
    {
        public frmListReturns()
        {
            InitializeComponent();
        }


        public void SalesReturns(DateTime startDate, DateTime endDate, string searchString)
        {

            try
            {
                SQLConn.sql = "SELECT sr.SalesReturnId, sr.ReturnDate, sr.InvoiceNo, CONCAT(s.lastname, ', ', s.firstname, ' ', s.MI) as StaffName, sr.TotalAmount, SUM(sri.Quantity) as TotalQuantity  FROM SalesReturn sr INNER JOIN SalesReturnItem sri ON sr.InvoiceNo = sri.InvoiceNo INNER JOIN Staff s ON s.StaffId = sr.userID WHERE convert(datetime,ReturnDate,103) BETWEEN convert(datetime,'" + startDate.ToShortDateString() + "',103) AND convert(datetime,'" + endDate.ToShortDateString() + "',103) AND sr.InvoiceNo LIKE '%" + txtName.Text + "%' GROUP BY sr.SalesReturnId, sr.ReturnDate, sr.InvoiceNo, sr.TotalAmount, s.lastname, s.firstname, s.MI ORDER BY ReturnDate, sr.InvoiceNo DESC";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();
                ListView2.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["SalesReturnId"].ToString());
                    x.SubItems.Add(Strings.Format(SQLConn.reader["ReturnDate"], "dd/MM/yyyy"));
                    x.SubItems.Add(SQLConn.reader["InvoiceNo"].ToString());
                    x.SubItems.Add(SQLConn.reader["StaffName"].ToString());
                    x.SubItems.Add(Strings.Format(SQLConn.reader["TotalAmount"], "#,##0.00"));
                    x.SubItems.Add(SQLConn.reader["TotalQuantity"].ToString());
                    //Strings.Format(SQLConn.reader["TotalAmount"], "#,##0.00")
                    ListView1.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        public void LoadReturnItems(string invoiceNo)
        {

            try
            {
                SQLConn.sql = "SELECT ProductCode, Description, Quantity, UnitPrice, (Quantity * UnitPrice) ExtendedPrice FROM SalesReturnItem sri INNER JOIN Product p ON p.ProductNo = sri.ProductID WHERE Sri.InvoiceNo = '" + invoiceNo + "' ORDER BY Description ";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView2.Items.Clear();


                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["ProductCode"].ToString());
                    x.SubItems.Add(SQLConn.reader["Description"].ToString());
                    x.SubItems.Add(SQLConn.reader["Quantity"].ToString());
                    x.SubItems.Add(Strings.Format(SQLConn.reader["UnitPrice"], "#,##0.00"));
                    x.SubItems.Add(Strings.Format(SQLConn.reader["ExtendedPrice"], "#,##0.00"));
                    //Strings.Format(SQLConn.reader["ExtendedPrice"], "#,##0.00")
                    ListView2.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void frmListReturns_Load(object sender, EventArgs e)
        {
            SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void dtStartDate_ValueChanged(object sender, EventArgs e)
        {
            SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void dtEndDate_ValueChanged(object sender, EventArgs e)
        {
            SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void ListView1_Click(object sender, EventArgs e)
        {
            try
            {
                LoadReturnItems(ListView1.FocusedItem.SubItems[2].Text);
            }
            catch
            {

            }
        }

        private void ToolStripButton4_Click(object sender, EventArgs e)
        {
            
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ToolStripButton2_Click(object sender, EventArgs e)
        {
            SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            SalesReturns(dtStartDate.Value, dtEndDate.Value, txtName.Text);
        }
    }
}
