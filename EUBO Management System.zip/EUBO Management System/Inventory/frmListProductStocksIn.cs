﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmListProductStocksIn : Form
    {
        int productID;
        public frmListProductStocksIn(int prodID)
        {
            InitializeComponent();
            productID = prodID;
        }

        private void GetProductInfo()
        {
           
            try
            {
                SQLConn.sql = "SELECT ProductCode, Description, UnitPrice, StocksOnHand FROM Product WHERE ProductNo =" + productID + "";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    lblProductCode.Text = SQLConn.reader[0].ToString();
                    lblDescription.Text = SQLConn.reader[1].ToString();
                    lblPrice.Text = Strings.FormatNumber(SQLConn.reader[2]).ToString();
                    lblCurrentStocks.Text = SQLConn.reader[3].ToString();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddStockIn()
        {
            try
            {
                SQLConn.sql = "INSERT INTO StockIn(StockInNo, ProductNo, Quantity, DateIn) Values('" + Utility.GetStockInNo() + "', '" + productID + "', '" + txtQuantity.Text + "', '" + System.DateTime.Now.ToString("dd/MM/yyyy") + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Le stock a été modifié avec succès.", MsgBoxStyle.Information, "Entrée de Stock");
                UpdateProductQuantity();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void UpdateProductQuantity()
        {
            try
            {
                SQLConn.sql = "UPDATE Product SET StocksOnhand = StocksOnHand + '" + Conversion.Val(txtQuantity.Text.Replace(",", "")) + "' WHERE ProductNo = '" + productID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void frmListProductStocksIn_Load(object sender, EventArgs e)
        {
            GetProductInfo();
            txtQuantity.Text = "";
            txtTotalStocks.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //AddStockIn();
            Utility.AddStockIn(productID, txtQuantity.Text, 0, 0);
            if (System.Windows.Forms.Application.OpenForms["frmListProduct"] != null)
            {
                (System.Windows.Forms.Application.OpenForms["frmListProduct"] as frmListProduct).LoadProducts("");
            }

            this.Close();
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            txtTotalStocks.Text = Strings.Format(Conversion.Val(lblCurrentStocks.Text) + Conversion.Val(txtQuantity.Text), "#,##0.00");
        }
    }
}
