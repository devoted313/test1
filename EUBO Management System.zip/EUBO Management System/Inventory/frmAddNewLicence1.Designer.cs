﻿namespace EMS
{
    partial class frmAddNewLicence1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddNewLicence1));
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.TabPage1 = new System.Windows.Forms.TabPage();
            this.lvwAddedProducts = new System.Windows.Forms.ListView();
            this.colCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDescription = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colQuantity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDiscount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAvailable = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.gbxTransaction = new System.Windows.Forms.GroupBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnSelectPartner = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.cbxTransactionType = new System.Windows.Forms.ComboBox();
            this.txtPartner = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpTransactionDate = new System.Windows.Forms.DateTimePicker();
            this.txtInvoiceNo = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.gbxArticle = new System.Windows.Forms.GroupBox();
            this.txtProductAmount = new System.Windows.Forms.TextBox();
            this.lblProductAmount = new System.Windows.Forms.Label();
            this.txtProductDiscount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtProductQty = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtProductStock = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtProductPrice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSelectProduct = new System.Windows.Forms.Button();
            this.txtProductRef = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblFormTitle = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnValidateLater = new System.Windows.Forms.Button();
            this.btnValidate = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtTransactionTotalAmount = new System.Windows.Forms.TextBox();
            this.lblTransactionTotalAmount = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.picMinimize = new System.Windows.Forms.PictureBox();
            this.picClose = new System.Windows.Forms.PictureBox();
            this.btnAdd = new System.Windows.Forms.PictureBox();
            this.btnRemove = new System.Windows.Forms.PictureBox();
            this.gbxComment = new System.Windows.Forms.GroupBox();
            this.txtComments = new System.Windows.Forms.RichTextBox();
            this.btnModuleArticles = new System.Windows.Forms.Button();
            this.btnAllTransactions = new System.Windows.Forms.Button();
            this.btnNewTransaction = new System.Windows.Forms.Button();
            this.TabControl1.SuspendLayout();
            this.TabPage1.SuspendLayout();
            this.ToolStrip1.SuspendLayout();
            this.gbxTransaction.SuspendLayout();
            this.gbxArticle.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRemove)).BeginInit();
            this.gbxComment.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.TabPage1);
            this.TabControl1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabControl1.Location = new System.Drawing.Point(2, 284);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(938, 369);
            this.TabControl1.TabIndex = 40;
            // 
            // TabPage1
            // 
            this.TabPage1.Controls.Add(this.lvwAddedProducts);
            this.TabPage1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPage1.Location = new System.Drawing.Point(4, 22);
            this.TabPage1.Name = "TabPage1";
            this.TabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage1.Size = new System.Drawing.Size(930, 343);
            this.TabPage1.TabIndex = 0;
            this.TabPage1.Text = "Articles ajoutés";
            this.TabPage1.UseVisualStyleBackColor = true;
            // 
            // lvwAddedProducts
            // 
            this.lvwAddedProducts.BackColor = System.Drawing.Color.White;
            this.lvwAddedProducts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colCode,
            this.colDescription,
            this.colPrice,
            this.colQuantity,
            this.colDiscount,
            this.colTotal,
            this.colAvailable});
            this.lvwAddedProducts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwAddedProducts.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvwAddedProducts.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lvwAddedProducts.FullRowSelect = true;
            this.lvwAddedProducts.GridLines = true;
            this.lvwAddedProducts.HideSelection = false;
            this.lvwAddedProducts.Location = new System.Drawing.Point(3, 3);
            this.lvwAddedProducts.Name = "lvwAddedProducts";
            this.lvwAddedProducts.Size = new System.Drawing.Size(924, 337);
            this.lvwAddedProducts.TabIndex = 37;
            this.lvwAddedProducts.UseCompatibleStateImageBehavior = false;
            this.lvwAddedProducts.View = System.Windows.Forms.View.Details;
            this.lvwAddedProducts.SelectedIndexChanged += new System.EventHandler(this.lvwAddedProducts_SelectedIndexChanged);
            this.lvwAddedProducts.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lvwAddedProducts_MouseClick);
            this.lvwAddedProducts.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lvwAddedProducts_MouseDoubleClick);
            // 
            // colCode
            // 
            this.colCode.Text = "Code";
            this.colCode.Width = 120;
            // 
            // colDescription
            // 
            this.colDescription.Text = "Description";
            this.colDescription.Width = 350;
            // 
            // colPrice
            // 
            this.colPrice.Text = "Prix";
            this.colPrice.Width = 100;
            // 
            // colQuantity
            // 
            this.colQuantity.Text = "Quantité";
            this.colQuantity.Width = 80;
            // 
            // colDiscount
            // 
            this.colDiscount.Text = "Remise";
            // 
            // colTotal
            // 
            this.colTotal.Text = "Total";
            this.colTotal.Width = 120;
            // 
            // colAvailable
            // 
            this.colAvailable.Text = "Disponibilité";
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.AutoSize = false;
            this.ToolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(116)))), ((int)(((byte)(170)))));
            this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripLabel1});
            this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.Size = new System.Drawing.Size(944, 40);
            this.ToolStrip1.TabIndex = 38;
            this.ToolStrip1.Text = "ToolStrip1";
            this.ToolStrip1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmStockInOut_MouseDown);
            // 
            // ToolStripLabel1
            // 
            this.ToolStripLabel1.Name = "ToolStripLabel1";
            this.ToolStripLabel1.Size = new System.Drawing.Size(16, 37);
            this.ToolStripLabel1.Text = "   ";
            // 
            // gbxTransaction
            // 
            this.gbxTransaction.BackColor = System.Drawing.Color.White;
            this.gbxTransaction.Controls.Add(this.txtStatus);
            this.gbxTransaction.Controls.Add(this.lblStatus);
            this.gbxTransaction.Controls.Add(this.btnSelectPartner);
            this.gbxTransaction.Controls.Add(this.label7);
            this.gbxTransaction.Controls.Add(this.cbxTransactionType);
            this.gbxTransaction.Controls.Add(this.txtPartner);
            this.gbxTransaction.Controls.Add(this.label3);
            this.gbxTransaction.Controls.Add(this.label4);
            this.gbxTransaction.Controls.Add(this.dtpTransactionDate);
            this.gbxTransaction.Controls.Add(this.txtInvoiceNo);
            this.gbxTransaction.Controls.Add(this.Label1);
            this.gbxTransaction.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxTransaction.Location = new System.Drawing.Point(5, 48);
            this.gbxTransaction.Name = "gbxTransaction";
            this.gbxTransaction.Size = new System.Drawing.Size(776, 89);
            this.gbxTransaction.TabIndex = 0;
            this.gbxTransaction.TabStop = false;
            this.gbxTransaction.Text = "Transaction";
            // 
            // txtStatus
            // 
            this.txtStatus.BackColor = System.Drawing.Color.White;
            this.txtStatus.Enabled = false;
            this.txtStatus.Location = new System.Drawing.Point(405, 54);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(140, 21);
            this.txtStatus.TabIndex = 11;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(351, 57);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(50, 13);
            this.lblStatus.TabIndex = 10;
            this.lblStatus.Text = "Statut :";
            // 
            // btnSelectPartner
            // 
            this.btnSelectPartner.BackColor = System.Drawing.Color.DarkGray;
            this.btnSelectPartner.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSelectPartner.BackgroundImage")));
            this.btnSelectPartner.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSelectPartner.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelectPartner.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSelectPartner.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectPartner.Location = new System.Drawing.Point(296, 52);
            this.btnSelectPartner.Name = "btnSelectPartner";
            this.btnSelectPartner.Size = new System.Drawing.Size(26, 23);
            this.btnSelectPartner.TabIndex = 9;
            this.btnSelectPartner.UseVisualStyleBackColor = false;
            this.btnSelectPartner.Click += new System.EventHandler(this.btnSelectPartner_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(54, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Type :";
            // 
            // cbxTransactionType
            // 
            this.cbxTransactionType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTransactionType.FormattingEnabled = true;
            this.cbxTransactionType.Location = new System.Drawing.Point(103, 24);
            this.cbxTransactionType.Margin = new System.Windows.Forms.Padding(2);
            this.cbxTransactionType.Name = "cbxTransactionType";
            this.cbxTransactionType.Size = new System.Drawing.Size(188, 21);
            this.cbxTransactionType.TabIndex = 2;
            this.cbxTransactionType.SelectedIndexChanged += new System.EventHandler(this.cbxTransactionType_SelectedIndexChanged);
            this.cbxTransactionType.SelectionChangeCommitted += new System.EventHandler(this.cbxTransactionType_SelectionChangeCommitted);
            // 
            // txtPartner
            // 
            this.txtPartner.BackColor = System.Drawing.Color.White;
            this.txtPartner.Enabled = false;
            this.txtPartner.Location = new System.Drawing.Point(103, 54);
            this.txtPartner.Name = "txtPartner";
            this.txtPartner.Size = new System.Drawing.Size(188, 21);
            this.txtPartner.TabIndex = 8;
            this.txtPartner.TextChanged += new System.EventHandler(this.txtPartner_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Partenaire :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(589, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Date :";
            // 
            // dtpTransactionDate
            // 
            this.dtpTransactionDate.CustomFormat = "dd/MM/yyyy";
            this.dtpTransactionDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTransactionDate.Location = new System.Drawing.Point(638, 24);
            this.dtpTransactionDate.Name = "dtpTransactionDate";
            this.dtpTransactionDate.Size = new System.Drawing.Size(102, 21);
            this.dtpTransactionDate.TabIndex = 6;
            this.dtpTransactionDate.ValueChanged += new System.EventHandler(this.dtEndDate_ValueChanged);
            // 
            // txtInvoiceNo
            // 
            this.txtInvoiceNo.BackColor = System.Drawing.Color.White;
            this.txtInvoiceNo.Enabled = false;
            this.txtInvoiceNo.Location = new System.Drawing.Point(405, 24);
            this.txtInvoiceNo.Name = "txtInvoiceNo";
            this.txtInvoiceNo.Size = new System.Drawing.Size(140, 21);
            this.txtInvoiceNo.TabIndex = 4;
            this.txtInvoiceNo.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(339, 27);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(61, 13);
            this.Label1.TabIndex = 3;
            this.Label1.Text = "Numéro :";
            // 
            // gbxArticle
            // 
            this.gbxArticle.BackColor = System.Drawing.Color.White;
            this.gbxArticle.Controls.Add(this.txtProductAmount);
            this.gbxArticle.Controls.Add(this.lblProductAmount);
            this.gbxArticle.Controls.Add(this.txtProductDiscount);
            this.gbxArticle.Controls.Add(this.label9);
            this.gbxArticle.Controls.Add(this.txtProductQty);
            this.gbxArticle.Controls.Add(this.label8);
            this.gbxArticle.Controls.Add(this.txtProductStock);
            this.gbxArticle.Controls.Add(this.label6);
            this.gbxArticle.Controls.Add(this.txtProductPrice);
            this.gbxArticle.Controls.Add(this.label2);
            this.gbxArticle.Controls.Add(this.btnSelectProduct);
            this.gbxArticle.Controls.Add(this.txtProductRef);
            this.gbxArticle.Controls.Add(this.label5);
            this.gbxArticle.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxArticle.Location = new System.Drawing.Point(6, 143);
            this.gbxArticle.Name = "gbxArticle";
            this.gbxArticle.Size = new System.Drawing.Size(776, 86);
            this.gbxArticle.TabIndex = 13;
            this.gbxArticle.TabStop = false;
            this.gbxArticle.Text = "Article";
            // 
            // txtProductAmount
            // 
            this.txtProductAmount.BackColor = System.Drawing.Color.White;
            this.txtProductAmount.Enabled = false;
            this.txtProductAmount.Location = new System.Drawing.Point(548, 56);
            this.txtProductAmount.Name = "txtProductAmount";
            this.txtProductAmount.Size = new System.Drawing.Size(134, 21);
            this.txtProductAmount.TabIndex = 26;
            // 
            // lblProductAmount
            // 
            this.lblProductAmount.AutoSize = true;
            this.lblProductAmount.Location = new System.Drawing.Point(478, 59);
            this.lblProductAmount.Name = "lblProductAmount";
            this.lblProductAmount.Size = new System.Drawing.Size(61, 13);
            this.lblProductAmount.TabIndex = 25;
            this.lblProductAmount.Text = "Montant :";
            // 
            // txtProductDiscount
            // 
            this.txtProductDiscount.BackColor = System.Drawing.Color.White;
            this.txtProductDiscount.Location = new System.Drawing.Point(322, 56);
            this.txtProductDiscount.Name = "txtProductDiscount";
            this.txtProductDiscount.Size = new System.Drawing.Size(125, 21);
            this.txtProductDiscount.TabIndex = 24;
            this.txtProductDiscount.TextChanged += new System.EventHandler(this.txtProductDiscount_TextChanged);
            this.txtProductDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProductDiscount_KeyDown);
            this.txtProductDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProductDiscount_KeyPress);
            this.txtProductDiscount.Leave += new System.EventHandler(this.txtProductDiscount_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(257, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Remise :";
            // 
            // txtProductQty
            // 
            this.txtProductQty.BackColor = System.Drawing.Color.White;
            this.txtProductQty.Location = new System.Drawing.Point(102, 56);
            this.txtProductQty.Name = "txtProductQty";
            this.txtProductQty.Size = new System.Drawing.Size(125, 21);
            this.txtProductQty.TabIndex = 22;
            this.txtProductQty.TextChanged += new System.EventHandler(this.txtProductQty_TextChanged);
            this.txtProductQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProductQty_KeyDown);
            this.txtProductQty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProductQty_KeyPress);
            this.txtProductQty.Leave += new System.EventHandler(this.txtProductQty_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Quantité :";
            // 
            // txtProductStock
            // 
            this.txtProductStock.BackColor = System.Drawing.Color.White;
            this.txtProductStock.Enabled = false;
            this.txtProductStock.Location = new System.Drawing.Point(638, 28);
            this.txtProductStock.Name = "txtProductStock";
            this.txtProductStock.Size = new System.Drawing.Size(134, 21);
            this.txtProductStock.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(545, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Disponibilité :";
            // 
            // txtProductPrice
            // 
            this.txtProductPrice.BackColor = System.Drawing.Color.White;
            this.txtProductPrice.Location = new System.Drawing.Point(397, 29);
            this.txtProductPrice.Name = "txtProductPrice";
            this.txtProductPrice.Size = new System.Drawing.Size(125, 21);
            this.txtProductPrice.TabIndex = 18;
            this.txtProductPrice.TextChanged += new System.EventHandler(this.txtProductPrice_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(350, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Prix :";
            // 
            // btnSelectProduct
            // 
            this.btnSelectProduct.BackColor = System.Drawing.Color.DarkGray;
            this.btnSelectProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSelectProduct.BackgroundImage")));
            this.btnSelectProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSelectProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelectProduct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSelectProduct.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectProduct.Location = new System.Drawing.Point(295, 26);
            this.btnSelectProduct.Name = "btnSelectProduct";
            this.btnSelectProduct.Size = new System.Drawing.Size(26, 23);
            this.btnSelectProduct.TabIndex = 16;
            this.btnSelectProduct.UseVisualStyleBackColor = false;
            this.btnSelectProduct.Click += new System.EventHandler(this.btnSelectProduct_Click);
            // 
            // txtProductRef
            // 
            this.txtProductRef.BackColor = System.Drawing.Color.White;
            this.txtProductRef.Enabled = false;
            this.txtProductRef.Location = new System.Drawing.Point(102, 28);
            this.txtProductRef.Name = "txtProductRef";
            this.txtProductRef.Size = new System.Drawing.Size(188, 21);
            this.txtProductRef.TabIndex = 15;
            this.txtProductRef.TextChanged += new System.EventHandler(this.txtProductRef_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Référence :";
            // 
            // lblFormTitle
            // 
            this.lblFormTitle.AutoSize = true;
            this.lblFormTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(116)))), ((int)(((byte)(170)))));
            this.lblFormTitle.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold);
            this.lblFormTitle.ForeColor = System.Drawing.Color.White;
            this.lblFormTitle.Location = new System.Drawing.Point(44, 7);
            this.lblFormTitle.Name = "lblFormTitle";
            this.lblFormTitle.Size = new System.Drawing.Size(194, 23);
            this.lblFormTitle.TabIndex = 48;
            this.lblFormTitle.Text = "Add New Licence";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(116)))), ((int)(((byte)(170)))));
            this.panel1.Controls.Add(this.btnValidateLater);
            this.panel1.Controls.Add(this.btnValidate);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.txtTransactionTotalAmount);
            this.panel1.Controls.Add(this.lblTransactionTotalAmount);
            this.panel1.Location = new System.Drawing.Point(0, 658);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(965, 49);
            this.panel1.TabIndex = 52;
            // 
            // btnValidateLater
            // 
            this.btnValidateLater.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnValidateLater.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidateLater.ForeColor = System.Drawing.Color.White;
            this.btnValidateLater.Location = new System.Drawing.Point(535, 5);
            this.btnValidateLater.Margin = new System.Windows.Forms.Padding(2);
            this.btnValidateLater.Name = "btnValidateLater";
            this.btnValidateLater.Size = new System.Drawing.Size(172, 37);
            this.btnValidateLater.TabIndex = 28;
            this.btnValidateLater.Text = "Valider ultérieurement";
            this.btnValidateLater.UseVisualStyleBackColor = false;
            this.btnValidateLater.Visible = false;
            this.btnValidateLater.Click += new System.EventHandler(this.btnValidateLater_Click);
            // 
            // btnValidate
            // 
            this.btnValidate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(182)))), ((int)(((byte)(118)))));
            this.btnValidate.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidate.ForeColor = System.Drawing.Color.White;
            this.btnValidate.Location = new System.Drawing.Point(826, 5);
            this.btnValidate.Margin = new System.Windows.Forms.Padding(2);
            this.btnValidate.Name = "btnValidate";
            this.btnValidate.Size = new System.Drawing.Size(110, 37);
            this.btnValidate.TabIndex = 30;
            this.btnValidate.Text = "Valider";
            this.btnValidate.UseVisualStyleBackColor = false;
            this.btnValidate.Click += new System.EventHandler(this.btnValidate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Red;
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(712, 5);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(110, 37);
            this.btnCancel.TabIndex = 29;
            this.btnCancel.Text = "Annuler";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtTransactionTotalAmount
            // 
            this.txtTransactionTotalAmount.BackColor = System.Drawing.Color.White;
            this.txtTransactionTotalAmount.Enabled = false;
            this.txtTransactionTotalAmount.Location = new System.Drawing.Point(229, 11);
            this.txtTransactionTotalAmount.Multiline = true;
            this.txtTransactionTotalAmount.Name = "txtTransactionTotalAmount";
            this.txtTransactionTotalAmount.Size = new System.Drawing.Size(186, 24);
            this.txtTransactionTotalAmount.TabIndex = 63;
            // 
            // lblTransactionTotalAmount
            // 
            this.lblTransactionTotalAmount.AutoSize = true;
            this.lblTransactionTotalAmount.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionTotalAmount.ForeColor = System.Drawing.Color.White;
            this.lblTransactionTotalAmount.Location = new System.Drawing.Point(10, 15);
            this.lblTransactionTotalAmount.Name = "lblTransactionTotalAmount";
            this.lblTransactionTotalAmount.Size = new System.Drawing.Size(215, 13);
            this.lblTransactionTotalAmount.TabIndex = 62;
            this.lblTransactionTotalAmount.Text = "Montant total de la transaction :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(116)))), ((int)(((byte)(170)))));
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(2, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(38, 37);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 49;
            this.pictureBox2.TabStop = false;
            // 
            // picMinimize
            // 
            this.picMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(116)))), ((int)(((byte)(170)))));
            this.picMinimize.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picMinimize.BackgroundImage")));
            this.picMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picMinimize.Location = new System.Drawing.Point(887, 2);
            this.picMinimize.Name = "picMinimize";
            this.picMinimize.Size = new System.Drawing.Size(25, 21);
            this.picMinimize.TabIndex = 47;
            this.picMinimize.TabStop = false;
            this.picMinimize.Click += new System.EventHandler(this.picMinimize_Click);
            // 
            // picClose
            // 
            this.picClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(116)))), ((int)(((byte)(170)))));
            this.picClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picClose.BackgroundImage")));
            this.picClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picClose.Location = new System.Drawing.Point(915, 2);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(25, 21);
            this.picClose.TabIndex = 46;
            this.picClose.TabStop = false;
            this.picClose.Click += new System.EventHandler(this.picClose_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Location = new System.Drawing.Point(6, 236);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(38, 41);
            this.btnAdd.TabIndex = 55;
            this.btnAdd.TabStop = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.White;
            this.btnRemove.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRemove.BackgroundImage")));
            this.btnRemove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnRemove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemove.Location = new System.Drawing.Point(48, 236);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(38, 41);
            this.btnRemove.TabIndex = 56;
            this.btnRemove.TabStop = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // gbxComment
            // 
            this.gbxComment.BackColor = System.Drawing.Color.White;
            this.gbxComment.Controls.Add(this.txtComments);
            this.gbxComment.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxComment.ForeColor = System.Drawing.Color.Black;
            this.gbxComment.Location = new System.Drawing.Point(108, 235);
            this.gbxComment.Margin = new System.Windows.Forms.Padding(2);
            this.gbxComment.Name = "gbxComment";
            this.gbxComment.Padding = new System.Windows.Forms.Padding(2);
            this.gbxComment.Size = new System.Drawing.Size(829, 64);
            this.gbxComment.TabIndex = 58;
            this.gbxComment.TabStop = false;
            this.gbxComment.Text = "Commentaires";
            // 
            // txtComments
            // 
            this.txtComments.BackColor = System.Drawing.SystemColors.Info;
            this.txtComments.Location = new System.Drawing.Point(4, 15);
            this.txtComments.Margin = new System.Windows.Forms.Padding(2);
            this.txtComments.MaxLength = 250;
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(822, 45);
            this.txtComments.TabIndex = 27;
            this.txtComments.Text = "";
            // 
            // btnModuleArticles
            // 
            this.btnModuleArticles.BackColor = System.Drawing.Color.IndianRed;
            this.btnModuleArticles.Font = new System.Drawing.Font("Verdana", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModuleArticles.ForeColor = System.Drawing.Color.White;
            this.btnModuleArticles.Location = new System.Drawing.Point(787, 193);
            this.btnModuleArticles.Margin = new System.Windows.Forms.Padding(2);
            this.btnModuleArticles.Name = "btnModuleArticles";
            this.btnModuleArticles.Size = new System.Drawing.Size(150, 32);
            this.btnModuleArticles.TabIndex = 27;
            this.btnModuleArticles.Text = "Accès Produits";
            this.btnModuleArticles.UseVisualStyleBackColor = false;
            this.btnModuleArticles.Click += new System.EventHandler(this.btnModuleArticles_Click);
            // 
            // btnAllTransactions
            // 
            this.btnAllTransactions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnAllTransactions.Font = new System.Drawing.Font("Verdana", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllTransactions.ForeColor = System.Drawing.Color.White;
            this.btnAllTransactions.Location = new System.Drawing.Point(787, 93);
            this.btnAllTransactions.Margin = new System.Windows.Forms.Padding(2);
            this.btnAllTransactions.Name = "btnAllTransactions";
            this.btnAllTransactions.Size = new System.Drawing.Size(150, 32);
            this.btnAllTransactions.TabIndex = 60;
            this.btnAllTransactions.Text = "Accès Transactions";
            this.btnAllTransactions.UseVisualStyleBackColor = false;
            this.btnAllTransactions.Click += new System.EventHandler(this.btnAllTransactions_Click);
            // 
            // btnNewTransaction
            // 
            this.btnNewTransaction.BackColor = System.Drawing.Color.Black;
            this.btnNewTransaction.Font = new System.Drawing.Font("Verdana", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewTransaction.ForeColor = System.Drawing.Color.White;
            this.btnNewTransaction.Location = new System.Drawing.Point(787, 56);
            this.btnNewTransaction.Margin = new System.Windows.Forms.Padding(2);
            this.btnNewTransaction.Name = "btnNewTransaction";
            this.btnNewTransaction.Size = new System.Drawing.Size(150, 32);
            this.btnNewTransaction.TabIndex = 59;
            this.btnNewTransaction.Text = "Nouvelle Transaction";
            this.btnNewTransaction.UseVisualStyleBackColor = false;
            this.btnNewTransaction.Click += new System.EventHandler(this.btnNewTransaction_Click);
            // 
            // frmAddNewLicence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(944, 704);
            this.ControlBox = false;
            this.Controls.Add(this.btnAllTransactions);
            this.Controls.Add(this.btnNewTransaction);
            this.Controls.Add(this.btnModuleArticles);
            this.Controls.Add(this.gbxComment);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblFormTitle);
            this.Controls.Add(this.picMinimize);
            this.Controls.Add(this.picClose);
            this.Controls.Add(this.gbxArticle);
            this.Controls.Add(this.gbxTransaction);
            this.Controls.Add(this.TabControl1);
            this.Controls.Add(this.ToolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmAddNewLicence";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmStockInOut_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmStockInOut_MouseDown);
            this.TabControl1.ResumeLayout(false);
            this.TabPage1.ResumeLayout(false);
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.gbxTransaction.ResumeLayout(false);
            this.gbxTransaction.PerformLayout();
            this.gbxArticle.ResumeLayout(false);
            this.gbxArticle.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRemove)).EndInit();
            this.gbxComment.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TabControl TabControl1;
        internal System.Windows.Forms.TabPage TabPage1;
        internal System.Windows.Forms.ListView lvwAddedProducts;
        internal System.Windows.Forms.ColumnHeader colCode;
        internal System.Windows.Forms.ColumnHeader colDescription;
        internal System.Windows.Forms.ColumnHeader colQuantity;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripLabel ToolStripLabel1;
        private System.Windows.Forms.ColumnHeader colPrice;
        private System.Windows.Forms.ColumnHeader colTotal;
        internal System.Windows.Forms.GroupBox gbxTransaction;
        private System.Windows.Forms.DateTimePicker dtpTransactionDate;
        internal System.Windows.Forms.TextBox txtInvoiceNo;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button btnSelectPartner;
        internal System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbxTransactionType;
        internal System.Windows.Forms.TextBox txtPartner;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.GroupBox gbxArticle;
        internal System.Windows.Forms.Button btnSelectProduct;
        internal System.Windows.Forms.TextBox txtProductRef;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.TextBox txtProductStock;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.TextBox txtProductAmount;
        internal System.Windows.Forms.Label lblProductAmount;
        internal System.Windows.Forms.TextBox txtProductDiscount;
        internal System.Windows.Forms.Label label9;
        internal System.Windows.Forms.TextBox txtProductQty;
        internal System.Windows.Forms.Label label8;
        internal System.Windows.Forms.TextBox txtProductPrice;
        internal System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox picMinimize;
        private System.Windows.Forms.PictureBox picClose;
        private System.Windows.Forms.Label lblFormTitle;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.TextBox txtTransactionTotalAmount;
        internal System.Windows.Forms.Label lblTransactionTotalAmount;
        private System.Windows.Forms.Button btnValidateLater;
        private System.Windows.Forms.Button btnValidate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.PictureBox btnAdd;
        private System.Windows.Forms.PictureBox btnRemove;
        private System.Windows.Forms.ColumnHeader colDiscount;
        private System.Windows.Forms.ColumnHeader colAvailable;
        private System.Windows.Forms.GroupBox gbxComment;
        private System.Windows.Forms.RichTextBox txtComments;
        internal System.Windows.Forms.TextBox txtStatus;
        internal System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Button btnModuleArticles;
        private System.Windows.Forms.Button btnAllTransactions;
        private System.Windows.Forms.Button btnNewTransaction;
    }
}