﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmReportDailSalesByUser : Form
    {
        DateTime ReportDate;
        public frmReportDailSalesByUser(DateTime reportDate)
        {
           
            InitializeComponent();

            ReportDate = reportDate;
        }

        private void frmReportDailSalesByUser_Load(object sender, EventArgs e)
        {

            LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                if (InvoiceSetting() == 1)
                {
                    //SQLConn.sql = "SELECT CONCAT(Lastname, ', ', Firstname, ' ', MI) as StaffName, ProductCode, P.Description, TDate, TTime,TD.ItemPrice, SUM(TD.Quantity) as totalQuantity, (TD.ItemPrice * SUM(TD.Quantity)) as TotalPrice  FROM Product as P, Transactions as T, TransactionDetails as TD, Staff as St WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND St.StaffID = T.StaffID AND  TDate = '" + ReportDate.ToString("dd/MM/yyyy") + "' AND T.Status != 1 GROUP BY  St.StaffID, P.ProductNo, TDate ORDER By TDate";
                    SQLConn.sql = "SELECT CONCAT(St.Lastname, ', ', St.Firstname, ' ', St.MI) as StaffName, P.ProductCode, P.Description, T.TDate, T.TTime, TD.ItemPrice, SUM(TD.Quantity) as totalQuantity, (TD.ItemPrice * SUM(TD.Quantity)) as TotalPrice FROM Product as P, Transactions as T, TransactionDetails as TD, Staff as St WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND St.StaffID = T.StaffID AND T.TDate = '" + ReportDate.ToShortDateString() + "' AND T.Status != 1 GROUP BY  St.StaffID, St.Lastname, St.Firstname, St.MI, P.ProductCode, P.Description, T.TDate, T.TTime,TD.ItemPrice, TD.Quantity ORDER By T.TDate";
                }
                else
                {
                    //SQLConn.sql = "SELECT CONCAT(Lastname, ', ', Firstname, ' ', MI) as StaffName, ProductCode, P.Description, REPLACE(TDate, '-', '/') as TDate, TTime,TD.ItemPrice, SUM(TD.Quantity) as totalQuantity, (TD.ItemPrice * SUM(TD.Quantity)) as TotalPrice  FROM Product as P, Transactions as T, TransactionDetails as TD, Staff as St WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND St.StaffID = T.StaffID AND  TDate = '" + ReportDate.ToString("dd/MM/yyyy") + "' GROUP BY  St.StaffID, P.ProductNo, TDate ORDER By TDate";
                    SQLConn.sql = "SELECT CONCAT(St.Lastname, ', ', St.Firstname, ' ', St.MI) as StaffName, P.ProductCode, P.Description, T.TDate, T.TTime, TD.ItemPrice, SUM(TD.Quantity) as totalQuantity, (TD.ItemPrice * SUM(TD.Quantity)) as TotalPrice FROM Product as P, Transactions as T, TransactionDetails as TD, Staff as St WHERE P.ProductNo = TD.ProductNo AND TD.InvoiceNo = T.InvoiceNo AND St.StaffID = T.StaffID AND T.TDate = '" + ReportDate.ToShortDateString() + "' GROUP BY  St.StaffID, St.Lastname, St.Firstname, St.MI, P.ProductCode, P.Description, T.TDate, T.TTime,TD.ItemPrice, TD.Quantity ORDER By T.TDate";
                }
                
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.da = new SqlDataAdapter(SQLConn.command);

                this.dsReportC.DailySalesByStaff.Clear();
                SQLConn.da.Fill(this.dsReportC.DailySalesByStaff);

                this.reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
                this.reportViewer1.ZoomPercent = 90;
                this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.Percent;

                this.reportViewer1.RefreshReport();

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
        }

        int InvoiceSetting()
        {
            int ret = 0;
            try
            {
                SQLConn.sql = "SELECT HInvoice FROM Company";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();


                if (SQLConn.reader.Read() == true)
                {
                    ret = Convert.ToInt32(SQLConn.reader["HInvoice"]);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }

            return ret;
        }
    }
}
