﻿using Microsoft.VisualBasic;
using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmApplications : Form
    {
        public string applicationID;

        public frmApplications()
        {
            InitializeComponent();
        }

        public void LoadApplications(string strSearch)
        {
            try
            {
                SQLConn.sql = "SELECT * FROM application WHERE application_name LIKE '" + strSearch + "%' ORDER By application_id desc";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader(CommandBehavior.CloseConnection);

                ListViewItem x = null;
                ListView1.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["application_id"].ToString());
                    x.SubItems.Add(SQLConn.reader["application_name"].ToString());
                    x.SubItems.Add(SQLConn.reader["application_description"].ToString());
                    ListView1.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            SQLConn.adding = true;
            SQLConn.updating = false;
            string init = "";
            frmAddEditApplication frm = new frmAddEditApplication(init);
            frm.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ListView1.Items.Count == 0)
            {
                Interaction.MsgBox("\r\nFirst you need to select a row.", MsgBoxStyle.Exclamation, "Update");
                return;
            }
            try
            {
                if (string.IsNullOrEmpty(ListView1.FocusedItem.Text))
                {
                   
                }
                else
                {
                    SQLConn.adding = false;
                    SQLConn.updating = true;
                    applicationID = ListView1.FocusedItem.Text;
                    frmAddEditApplication frm = new frmAddEditApplication(applicationID);
                    frm.ShowDialog();
                }
            }
            catch 
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner une ligne.", MsgBoxStyle.Exclamation, "Mise à jour");
                return;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SQLConn.strSearch = Interaction.InputBox("ENTER Measure unit NAME.", "Search Measure Unit", " ");
           
            if (SQLConn.strSearch.Length >= 1)
            {
                LoadApplications(SQLConn.strSearch.Trim());
            }
            else if (string.IsNullOrEmpty(SQLConn.strSearch))
            {
                return;
            }
        }


        private void frmListLocation_Load(object sender, EventArgs e)
        {
            LoadApplications("");
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SQLConn.strSearch = textBox1.Text;

            if (SQLConn.strSearch.Length >= 1 || string.IsNullOrEmpty(SQLConn.strSearch))
            {
                LoadApplications(SQLConn.strSearch.Trim());
            }
        }

        private void ListView1_DoubleClick(object sender, EventArgs e)
        {
            Modifier();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Modifier();
        }

        private void Modifier()
        {
            SQLConn.adding = false;
            SQLConn.updating = true;
            applicationID = ListView1.FocusedItem.Text;
            frmAddEditApplication frm = new frmAddEditApplication(applicationID);
            frm.ShowDialog();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (ListView1.SelectedItems.Count == 0)
            {
                e.Cancel = true;
            }
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (ListView1.FocusedItem.Bounds.Contains(e.Location))
                {
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
        }
    }
}
