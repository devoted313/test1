﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmAddProductQuick : Form
    {
        int categoryID;
        int measureunitID;

        //  frmPOS POS;
        public frmAddProductQuick(Form callingForm)
        {
            InitializeComponent();
        //    POS = callingForm as frmPOS;
        }

        private void GetProductNo()
        {
            try
            {
                SQLConn.sql = "SELECT ProductNo FROM Product ORDER BY ProductNo DESC";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    lblProductNo.Text = (Convert.ToInt32(SQLConn.reader["ProductNo"]) + 1).ToString();
                }
                else
                {
                    lblProductNo.Text = "1";
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }


        private void AddProducts()
        {

            string barcode = "";

            if (barcode.Trim() == "")
            {
                barcode = "NO BARCODE";
            }
            else
            {
                barcode = "";
            }

            try
            {
                SQLConn.sql = "INSERT INTO Product(ProductCode, Description, Barcode, UnitPrice, StocksOnHand, ReorderLevel, CategoryNo, measure_unit_id) VALUES('" + txtProductCode.Text + "', '" + txtDescription.Text + "', '" + barcode + "', '" + txtUnitPrice.Text.Replace(",", "") + "', '" + txtStocksOnHand.Text.Replace(",", "") + "', '" + txtReorderLevel.Text + "', '" + categoryID + "', '" + measureunitID + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Product successfully added.", MsgBoxStyle.Information, "Add Product");
                AddStockIn();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddStockIn()
        {
            try
            {
                SQLConn.sql = "INSERT INTO StockIn(ProductNo, Quantity, DateIn) Values('" + lblProductNo.Text + "', '" + txtStocksOnHand.Text + "', '" + System.DateTime.Now.ToString("dd/MM/yyyy") + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        public string Category
        {
            get { return txtCategory.Text; }
            set { txtCategory.Text = value; }
        }

        public int CategoryID
        {
            get { return categoryID; }
            set { categoryID = value; }
        }

        public string MeasureUnit
        {
            get { return txtMeasureUnit.Text; }
            set { txtMeasureUnit.Text = value; }
        }

        public int MeasureunitID
        {
            get { return measureunitID; }
            set { measureunitID = value; }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            frmSelectCategory flc = new frmSelectCategory(this, true);
            flc.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (txtDescription.Text == "")
            {
                Interaction.MsgBox("Vous devez entrer la description du produit");
                return;
            }

            if (txtUnitPrice.Text == "")
            {
                Interaction.MsgBox("Vous devez entrer le stock disponible");
                return;
            }


            if (txtStocksOnHand.Text == "")
            {
                Interaction.MsgBox("Vous devez entrer le stock disponible");
                return;
            }


            AddProducts();
          //  this.Hide();
          
        
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAddProductQuick_Load(object sender, EventArgs e)
        {
            GetProductNo();
        }
    }
}
