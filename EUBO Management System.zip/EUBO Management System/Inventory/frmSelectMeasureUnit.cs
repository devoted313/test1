﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmSelectMeasureUnit : Form
    {
        private frmAddEditProduct frmProduct = null;
        private frmAddProductQuick frmProductQuick = null;
        bool IsQuickAdd;
        public frmSelectMeasureUnit(Form callingForm, bool isQuickAdd)
        {
            InitializeComponent();

            if (isQuickAdd != true)
            {
                frmProduct = callingForm as frmAddEditProduct;
            }
            else
            {
                frmProductQuick = callingForm as frmAddProductQuick;
            }
            
            
            IsQuickAdd = isQuickAdd;
        }

        private void LoadMeasureUnit()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM measure_unit WHERE measure_unit_name LIKE '" + txtUM.Text + "%' ORDER BY measure_unit_id desc";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                ListViewItem x = null;
                ListView1.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["measure_unit_id"].ToString());
                    x.SubItems.Add(SQLConn.reader["measure_unit_name"].ToString());
                    x.SubItems.Add(SQLConn.reader["measure_unit_description"].ToString());

                    ListView1.Items.Add(x);
                }

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmSelectMeasureUnit_Load(object sender, EventArgs e)
        {
            LoadMeasureUnit();
        }

        private void ListView1_DoubleClick(object sender, EventArgs e)
        {

            int id = Convert.ToInt32(ListView1.FocusedItem.Text);

            if (IsQuickAdd != true)
            {
                this.frmProduct.MeasureunitID = id;
                this.frmProduct.MeasureUnit = ListView1.FocusedItem.SubItems[1].Text;
            }
            else
            {
                this.frmProductQuick.MeasureunitID = id;
                this.frmProductQuick.MeasureUnit = ListView1.FocusedItem.SubItems[1].Text;
            }
           
            this.Close();
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtUM_TextChanged(object sender, EventArgs e)
        {
            LoadMeasureUnit();
        }
    }
}
