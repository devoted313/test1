﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmAddEditMeasureUnit : Form
    {
        int measureUnitID;
        public frmAddEditMeasureUnit(int smeasureUnitID)
        {
            InitializeComponent();

            measureUnitID = smeasureUnitID;
        }

        private void LoadUpdateMeasureUnit()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM measure_unit WHERE measure_unit_id = '" + measureUnitID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    txtMeasureUnitId.Text = SQLConn.reader["measure_unit_id"].ToString();
                    txtMeasureUnitName.Text = SQLConn.reader["measure_unit_name"].ToString();
                    txtMeasureUnitDescription.Text = SQLConn.reader["measure_unit_description"].ToString();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddMeasureUnit()
        {
            try
            {
                SQLConn.sql = "INSERT INTO measure_unit(measure_unit_id, measure_unit_name, measure_unit_description) VALUES('" + Utility.GetMeasureUnitID() + "', '" + txtMeasureUnitName.Text + "', '" + txtMeasureUnitDescription.Text + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Nouvelle unité de mesure ajoutée avec succès.", MsgBoxStyle.Information, "Ajout d'une nouvelle unité de mesure");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void UpdateMeasureUnit()
        {
            try
            {
                SQLConn.sql = "UPDATE measure_unit SET measure_unit_name= '" + txtMeasureUnitName.Text + "', measure_unit_description = '" + txtMeasureUnitDescription.Text + "' WHERE measure_unit_id = '" + measureUnitID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Mise à jour effectuée avec succès.", MsgBoxStyle.Information, "Mise à jour d'une unité de mesure");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void CLearFields()
        {
            txtMeasureUnitId.Text = "";
            txtMeasureUnitName.Text = "";
            txtMeasureUnitDescription.Text = "";
        }

        private void frmAddEditMeasureUnit_Load(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                lblTitle.Text = "Ajout d'une unité de mesure";
                CLearFields();
                txtMeasureUnitId.Text = Utility.GetMeasureUnitID();
            }
            else
            {
                lblTitle.Text = "Mise à jour de l'unité de mesure";
                LoadUpdateMeasureUnit();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                AddMeasureUnit();
            }
            else
            {
                UpdateMeasureUnit();
               
            }
            if (System.Windows.Forms.Application.OpenForms["frmListMeasureUnit"] != null)
            {
                (System.Windows.Forms.Application.OpenForms["frmListMeasureUnit"] as frmListMeasureUnit).LoadMeasureUnits("");
            }

            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
