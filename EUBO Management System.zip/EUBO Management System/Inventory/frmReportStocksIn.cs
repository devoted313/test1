﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using System.Data.SqlClient;
using System.Security;
using System.Security.Permissions;

namespace EMS
{
    public partial class frmReportStocksIn : Form
    {
        DateTime StartDate;
        DateTime EndDate;
        public frmReportStocksIn(DateTime startDate, DateTime endDate)
        {
            InitializeComponent();
            StartDate = startDate;
            EndDate = endDate;

        }

        private void frmReportStocksIn_Load(object sender, EventArgs e)
        {
            LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                SQLConn.sql = "SELECT P.ProductCode, P.Description, SUM(Quantity) as Quantity, S.DateIn FROM Product as P, StockIn as S WHERE S.ProductNo = P.ProductNo AND convert(datetime,DateIn, 103) BETWEEN convert(datetime,'" + StartDate.ToShortDateString() + "',103) AND convert(datetime,'" + EndDate.ToShortDateString() + "',103) GROUP BY P.ProductCode, P.Description, S.DateIN ORDER BY DateIn, Description";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.da = new SqlDataAdapter(SQLConn.command);

                this.dsReportC.StocksIn.Clear();
                SQLConn.da.Fill(this.dsReportC.StocksIn);

                ReportParameter startDate = new ReportParameter("StartDate", StartDate.ToShortDateString());
                ReportParameter endDate = new ReportParameter("EndDate", EndDate.ToShortDateString());

                this.reportViewer1.LocalReport.SetParameters(new ReportParameter[] { startDate, endDate });

                this.reportViewer1.SetDisplayMode(DisplayMode.PrintLayout);
                this.reportViewer1.ZoomPercent = 90;
                this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.Percent;

                this.reportViewer1.RefreshReport();

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
        }
    }
}
