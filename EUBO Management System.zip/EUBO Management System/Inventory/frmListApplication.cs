﻿using Microsoft.VisualBasic;
using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class frmListApplication : Form
    {
        public string applicationID;

        public frmListApplication()
        {
            InitializeComponent();
        }

        public void LoadApplications(string strSearch)
        {
            try
            {
                SQLConn.sql = "SELECT * FROM application WHERE application_name LIKE '" + strSearch + "%' ORDER By application_id desc";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader(CommandBehavior.CloseConnection);

                ListViewItem x = null;
                ListView1.Items.Clear();

                while (SQLConn.reader.Read() == true)
                {
                    x = new ListViewItem(SQLConn.reader["application_id"].ToString());
                    x.SubItems.Add(SQLConn.reader["application_name"].ToString());
                    x.SubItems.Add(SQLConn.reader["application_description"].ToString());
                    ListView1.Items.Add(x);
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            SQLConn.adding = true;
            SQLConn.updating = false;
            string init = "";
            frmAddEditApplication faea = new frmAddEditApplication(init);
            faea.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ListView1.Items.Count == 0)
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner une ligne", MsgBoxStyle.Exclamation, "Mise à jour");
                return;
            }
            try
            {
                if (string.IsNullOrEmpty(ListView1.FocusedItem.Text))
                {
                   
                }
                else
                {
                    SQLConn.adding = false;
                    SQLConn.updating = true;
                    applicationID = ListView1.FocusedItem.Text;
                    frmAddEditApplication aea = new frmAddEditApplication(applicationID);
                    aea.ShowDialog();
                }
            }   
            catch 
            {
                Interaction.MsgBox("Vous devez d'abord sélectionner une ligne", MsgBoxStyle.Exclamation, "Mise à jour");
                return;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SQLConn.strSearch = Interaction.InputBox("ENTER Partner NAME.", "Search Partner", " ");
           
            if (SQLConn.strSearch.Length >= 1)
            {
                LoadApplications(SQLConn.strSearch.Trim());
            }
            else if (string.IsNullOrEmpty(SQLConn.strSearch))
            {
                return;
            }
        }


        private void frmListPartner_Load(object sender, EventArgs e)
        {
            LoadApplications("");
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SQLConn.strSearch = textBox1.Text;

            if (SQLConn.strSearch.Length >= 1 || string.IsNullOrEmpty(SQLConn.strSearch))
            {
                LoadApplications(SQLConn.strSearch.Trim());
            }
        }

        private void ListView1_DoubleClick(object sender, EventArgs e)
        {
            Modifier();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Modifier();
        }

        private void Modifier()
        {
            SQLConn.adding = false;
            SQLConn.updating = true;
            applicationID = ListView1.FocusedItem.Text;
            frmAddEditApplication aeC = new frmAddEditApplication(applicationID);
            aeC.ShowDialog();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (ListView1.SelectedItems.Count == 0)
            {
                e.Cancel = true;
            }
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (ListView1.FocusedItem.Bounds.Contains(e.Location))
                {
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
        }


        SqlConnection con = new SqlConnection(SQLConn.connectionString);
        int partnerid = 0;

        private void supprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            partnerid = Convert.ToInt32(ListView1.FocusedItem.Text);

            if (partnerid > 0)
            {
                //if (!Utility.isPartnerExistInProductTable(partnerid))
                //{
                    SqlCommand cmd = new SqlCommand("delete from application where application_id = @applicationid", con);
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@applicationid", this.applicationID);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("La ligne sélectionnée a bien été supprimée.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadApplications(SQLConn.strSearch.Trim());
                //}
                //else
                    //MessageBox.Show("La ligne ne peut pas être supprimée car elle est liée à un produit.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Vous devez d'abord sélectionné une ligne.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
