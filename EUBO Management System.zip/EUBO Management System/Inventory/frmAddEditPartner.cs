﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmAddEditPartner : Form
    {
        int partnerID;
        public frmAddEditPartner(int spartnerid)
        {
            InitializeComponent();

            partnerID = spartnerid;
        }

        private void LoadUpdatePartner()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM partner WHERE partner_id = '" + partnerID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    txtPartnerId.Text = SQLConn.reader["partner_id"].ToString();
                    txtPartnerName.Text = SQLConn.reader["partner_name"].ToString();
                    txtPartnerDescription.Text = SQLConn.reader["partner_description"].ToString();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddPartner()
        {
            try
            {
                SQLConn.sql = "INSERT INTO partner(partner_id, partner_name, partner_description) VALUES('" + Utility.GetPartnerID() + "', '" + txtPartnerName.Text + "', '" + txtPartnerDescription.Text + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Nouveau partenaire ajouté avec succès.", MsgBoxStyle.Information, "Ajout d'un partenaire");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void UpdatePartner()
        {
            try
            {
                SQLConn.sql = "UPDATE partner SET partner_name= '" + txtPartnerName.Text + "', partner_description = '" + txtPartnerDescription.Text + "' WHERE partner_id = '" + partnerID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Mise à jour effectuée avec succès.", MsgBoxStyle.Information, "Mise à jour d'un partenaire");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void CLearFields()
        {
            txtPartnerId.Text = "";
            txtPartnerName.Text = "";
            txtPartnerDescription.Text = "";
        }

        private void frmAddEditPartner_Load(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                lblTitle.Text = "Ajout d'un nouveau partenaire";
                CLearFields();
                txtPartnerId.Text = Utility.GetPartnerID();
            }
            else
            {
                lblTitle.Text = "Mise à jour d'un partenaire";
                LoadUpdatePartner();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                AddPartner();
            }
            else
            {
                UpdatePartner();
               
            }
            if (System.Windows.Forms.Application.OpenForms["frmListApplication"] != null)
            {
                (System.Windows.Forms.Application.OpenForms["frmListApplication"] as frmListApplication).LoadApplications("");
            }

            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
