﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using InsertUpdateDeleteDemo;
using Microsoft.VisualBasic;

namespace EMS
{
    public partial class frmMain : Form
    {
        string Username;
        int StaffID;
        public frmMain(string username, int staffID)
        {
            InitializeComponent();
            Username = username;
            StaffID = staffID;
        }

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            SQLConn.getData();
            //this.lbluser.Text = "Utilisateur connecté : " + Username.ToUpper();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            if (Interaction.MsgBox("Êtes vous sûr de vouloir quitter?", MsgBoxStyle.YesNo, "Fermeture de l'application") == MsgBoxResult.Yes)
            {
                Application.Exit();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmListStaff f1 = new frmListStaff();
            f1.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDateTime.Text = "Date/Heure : " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss tt");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            frmDatabaseConfig db = new frmDatabaseConfig();
            db.ShowDialog();
        }

        private void btnCategory_Click(object sender, EventArgs e)
        {
            frmListCategory lc = new frmListCategory();
            lc.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (Interaction.MsgBox("Êtes vous sûr de vouloir quitter?", MsgBoxStyle.YesNo, "Fermeture de l'application") == MsgBoxResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmListProduct lp = new frmListProduct();
            lp.ShowDialog();
        }

        private void btnTransaction_Click(object sender, EventArgs e)
        {
            frmAddNewLicence1 fsio = new frmAddNewLicence1();
            fsio.ShowDialog();
        }

        private void picMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmReportFilterDailySales FR = new frmReportFilterDailySales();
            FR.ShowDialog();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            frmSystemSetting ss = new frmSystemSetting();
            ss.ShowDialog();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            frmListReturns lr = new frmListReturns();
            lr.ShowDialog();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void frmMain_MouseDown(object sender,
        System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        int count = 0;

        private void label1_DoubleClick(object sender, EventArgs e)
        {
            /*
            this.count++;
            if (this.count % 2 == 0)
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Normal;
            }
            else
            {
                this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            }
            */
        }

        private void btnMeasureUnit_Click(object sender, EventArgs e)
        {
            frmListMeasureUnit flmu = new frmListMeasureUnit();
            flmu.ShowDialog();
        }

        private void btnPartner_Click(object sender, EventArgs e)
        {
            frmListApplication flp = new frmListApplication();
            flp.ShowDialog();
        }

        private void btnStocksReport_Click(object sender, EventArgs e)
        {
            frmReportFilterStocks rf = new frmReportFilterStocks();
            rf.ShowDialog();
        }

        private void btnAllTransactions_Click(object sender, EventArgs e)
        {
            frmAllTransactions frm = new frmAllTransactions();
            frm.Show();
        }

        private void btnLocation_Click(object sender, EventArgs e)
        {
            frmApplications frm = new frmApplications();
            frm.ShowDialog();
        }

        private void btnNotes_Click(object sender, EventArgs e)
        {
            frmNotes frm = new frmNotes();
            frm.ShowDialog();
        }

        private void btnCharges_Click(object sender, EventArgs e)
        {
            frmCharges frm = new frmCharges();
            frm.ShowDialog();
        }

        private void btnCredits_Click(object sender, EventArgs e)
        {
            frmCredits frm = new frmCredits();
            frm.ShowDialog();
        }

        private void btnLicence_Click(object sender, EventArgs e)
        {

        }

        private void gbxGestion_Enter(object sender, EventArgs e)
        {

        }

        private void btnApplications_Click(object sender, EventArgs e)
        {
            frmApplications frm = new frmApplications();
            frm.ShowDialog();
        }
    }
}
