﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmAddEditApplication : Form
    {
        string ApplicationID;
        public frmAddEditApplication(string sApplicationID)
        {
            InitializeComponent();

            ApplicationID = sApplicationID;
        }

        private void LoadUpdateApplication()
        {
            try
            {
                SQLConn.sql = "SELECT * FROM application WHERE application_id = '" + ApplicationID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    txtApplicationId.Text = SQLConn.reader["application_id"].ToString();
                    txtApplicationName.Text = SQLConn.reader["application_name"].ToString();
                    txtApplicationDescription.Text = SQLConn.reader["application_description"].ToString();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddApplication()
        {
            try
            {
                SQLConn.sql = "INSERT INTO application(application_id, application_name, application_description) VALUES('" + txtApplicationId.Text + "', '" + txtApplicationName.Text + "', '" + txtApplicationDescription.Text + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Application added successfully.", MsgBoxStyle.Information, "New Application");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void UpdateApplication()
        {
            try
            {
                SQLConn.sql = "UPDATE application SET application_name= '" + txtApplicationName.Text + "', application_description = '" + txtApplicationDescription.Text + "' WHERE application_id = '" + ApplicationID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Update completed successfully.", MsgBoxStyle.Information, "Application update");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void CLearFields()
        {
            txtApplicationId.Text = "";
            txtApplicationName.Text = "";
            txtApplicationDescription.Text = "";
        }

        private void frmAddEditApplication_Load(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                lblTitle.Text = "New Application";
                CLearFields();
                txtApplicationId.Text = Utility.GetApplicationID();
            }
            else
            {
                lblTitle.Text = "Update Application";
                LoadUpdateApplication();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                AddApplication();
            }
            else
            {
                UpdateApplication();
            }
            if (System.Windows.Forms.Application.OpenForms["frmListApplication"] != null)
            {
                (System.Windows.Forms.Application.OpenForms["frmListApplication"] as frmApplications).LoadApplications("");
            }

            this.Close();
        }
    }
}
