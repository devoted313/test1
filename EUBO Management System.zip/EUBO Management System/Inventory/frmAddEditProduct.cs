﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace EMS
{
    public partial class frmAddEditProduct : Form
    {
        int productID;
        int categoryID;
        int measureunitID;

        string sBarcode = "";

        public frmAddEditProduct(int prodID, int catID, int muID)
        {
            InitializeComponent();
            productID = prodID;
            categoryID = catID;
            measureunitID = muID;
        }

        private void GetProductNo()
        {
            try
            {
                SQLConn.sql = "SELECT ProductNo FROM Product ORDER BY ProductNo DESC";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    lblProductNo.Text = (Convert.ToInt32(SQLConn.reader["ProductNo"]) + 1).ToString();
                }
                else
                {
                    lblProductNo.Text = "1";
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }


        private void LoadUpdateCategory()
        {
            try
            {
                SQLConn.sql = "SELECT ProductNo, ProductCode, P.Description, Barcode, P.CategoryNo, CategoryName, P.measure_unit_id, measure_unit_name, UnitPrice, StocksOnHand, ReorderLevel FROM Product as P LEFT JOIN Category as C ON P.CategoryNo = C.CategoryNo LEFT JOIN measure_unit as m ON P.measure_unit_id = m.measure_unit_id WHERE ProductNo = '" + productID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();

                if (SQLConn.reader.Read() == true)
                {
                    lblProductNo.Text = SQLConn.reader["ProductNo"].ToString();
                    txtProductCode.Text = SQLConn.reader["ProductCode"].ToString();
                    txtDescription.Text = SQLConn.reader["Description"].ToString();
                    sBarcode = SQLConn.reader["Barcode"].ToString();
                    txtCategory.Text = SQLConn.reader["CategoryName"].ToString();
                    txtCategory.Tag = SQLConn.reader["CategoryNo"];
                    txtMeasureUnit.Text = SQLConn.reader["measure_unit_name"].ToString();
                    txtMeasureUnit.Tag = SQLConn.reader["measure_unit_id"];
                    txtUnitPrice.Text = Strings.Format(SQLConn.reader["UnitPrice"], "#,##0.00");
                    txtStocksOnHand.Text = SQLConn.reader["StocksOnHand"].ToString();
                    txtReorderLevel.Text = SQLConn.reader["ReorderLevel"].ToString();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }


        private void AddProducts()
        {
            string barcode = "";

            if (sBarcode.Trim() == "")
            {
                barcode = "NO BARCODE";
            }
            else
            {
                barcode = sBarcode;
            }

            try
            {
                SQLConn.sql = "INSERT INTO Product(ProductNo, ProductCode, Description, Barcode, UnitPrice, StocksOnHand, ReorderLevel, CategoryNo, measure_unit_id) VALUES('" + lblProductNo.Text + "', '" + txtProductCode.Text + "', '" + txtDescription.Text + "', '" + barcode + "', '" + txtUnitPrice.Text.Replace(",", "") + "', '" + txtStocksOnHand.Text.Replace(",", "") + "', '" + txtReorderLevel.Text + "', '" + categoryID + "', '" + measureunitID + "')";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
                Interaction.MsgBox("Produit ajouté avec succès.", MsgBoxStyle.Information, "Ajout d'un produit");
                AddStockIn();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void AddStockIn()
        {
            try
            {
                SQLConn.sql = "INSERT INTO StockIn(Stockinno, ProductNo, Quantity, DateIn, status) Values('" + lblProductNo.Text + "', '" + lblProductNo.Text + "', '" + txtStocksOnHand.Text + "', '" + System.DateTime.Now.ToString("dd/MM/yyyy") + "',0)";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void UpdateProduct()
        {
            try
            {
                float fUnitPrice = float.Parse(txtUnitPrice.Text);
                string sUnitPrice = fUnitPrice.ToString().Replace(',', '.');

                float fStocksOnHand = float.Parse(txtStocksOnHand.Text);
                string sStocksOnHand = fStocksOnHand.ToString().Replace(',', '.');

                SQLConn.sql = "UPDATE Product SET ProductCode = '" + txtProductCode.Text.Replace("'", "''") + "', Description = '" + txtDescription.Text.Replace("'","''") + "', Barcode = '" + sBarcode.Trim() + "', UnitPrice = '" + sUnitPrice + "', StocksOnHand = '" + sStocksOnHand + "', ReorderLevel = '" + txtReorderLevel.Text + "', CategoryNo ='" + categoryID + "', measure_unit_id='" + measureunitID + "' WHERE ProductNo = '" + productID + "'";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.command.ExecuteNonQuery();

                Interaction.MsgBox("Produit modifié avec succès.", MsgBoxStyle.Information, "Modification d'un produit");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private void ClearFields()
        {
            lblProductNo.Text = "";
            txtProductCode.Text = "";
            txtDescription.Text = "";
            sBarcode = "";
            txtCategory.Text = "";
            txtUnitPrice.Text = "0";
            txtStocksOnHand.Text = "0";
            txtReorderLevel.Text = "";
        }

        private void frmAddEditProduct_Load(object sender, EventArgs e)
        {
            if (SQLConn.adding == true)
            {
                lblTitle.Text = "Ajout d'un produit";
                ClearFields();
                GetProductNo();
            }
            else
            {
                lblTitle.Text = "Mise à jour d'un produit";
                LoadUpdateCategory();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtCategory.Text.Trim() == string.Empty)
            {
                Interaction.MsgBox("Vous devez sélectionner une catégorie.", MsgBoxStyle.Critical, "Categorie");
                txtCategory.BackColor = Color.Red;
                return;
            }

            if (txtMeasureUnit.Text.Trim() == string.Empty)
            {
                Interaction.MsgBox("Vous devez sélectionner une unité de mesure.", MsgBoxStyle.Critical, "Unité de mesure");
                txtMeasureUnit.BackColor = Color.Red;
                return;
            }

            if (txtUnitPrice.Text.Trim() == string.Empty)
            {
                Interaction.MsgBox("Vous devez définir un prix.", MsgBoxStyle.Critical, "Prix");
                txtUnitPrice.BackColor = Color.Red;
                return;
            }

            if (txtStocksOnHand.Text.Trim() == string.Empty)
            {
                Interaction.MsgBox("Vous devez définir un stock initial.", MsgBoxStyle.Critical, "Stock initial");
                txtStocksOnHand.BackColor = Color.Red;
                return;
            }

            if (SQLConn.adding == true)
            {
                AddProducts();
            }
            else
            {
                UpdateProduct();  
            }

            if (System.Windows.Forms.Application.OpenForms["frmListProduct"] != null)
            {
                (System.Windows.Forms.Application.OpenForms["frmListProduct"] as frmListProduct).LoadProducts("");
            }

            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            frmSelectCategory flc = new frmSelectCategory(this, false);
            flc.ShowDialog();
        }

        public string Category
        {
            get { return txtCategory.Text; }
            set { txtCategory.Text = value; }
        }

        public int CategoryID
        {
            get { return categoryID; }
            set { categoryID = value; }
        }

        public string MeasureUnit
        {
            get { return txtMeasureUnit.Text; }
            set { txtMeasureUnit.Text = value; }
        }

        public int MeasureunitID
        {
            get { return measureunitID; }
            set { measureunitID = value; }
        }

        private void btnMeasureUnit_Click(object sender, EventArgs e)
        {
            frmSelectMeasureUnit fmu = new frmSelectMeasureUnit(this, false);
            fmu.ShowDialog();
        }

        private void txtStocksOnHand_TextChanged(object sender, EventArgs e)
        {
            //if (System.Text.RegularExpressions.Regex.IsMatch(txtStocksOnHand.Text, "  ^ [0-9]"))
            //{
            //    txtStocksOnHand.Text = "";
            //}

            char[] originalText = txtStocksOnHand.Text.ToCharArray();
            foreach (char c in originalText)
            {
                if (!(Char.IsNumber(c)) || txtStocksOnHand.Text.StartsWith("0"))
                {
                    txtStocksOnHand.Text = txtStocksOnHand.Text.Remove(txtStocksOnHand.Text.IndexOf(c));
                }
            }
            txtStocksOnHand.Select(txtStocksOnHand.Text.Length, 0);
        }

        private void txtStocksOnHand_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;

            }
        }

        private void txtUnitPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            Utility.onlynumwithsinglecomma(sender, e);

            txtUnitPrice.BackColor = Color.White;
        }

        private void txtUnitPrice_TextChanged(object sender, EventArgs e)
        {
            txtUnitPrice.BackColor = Color.White;
            if (System.Text.RegularExpressions.Regex.IsMatch(txtUnitPrice.Text, "  ^ [0-9]"))
            {
                txtUnitPrice.Text = "";
            }
        }

        private void txtCategory_TextChanged(object sender, EventArgs e)
        {
            txtCategory.BackColor = Color.White;
        }

        private void txtMeasureUnit_TextChanged(object sender, EventArgs e)
        {
            txtMeasureUnit.BackColor = Color.White;
        }
    }
}
