﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using EMS;
using System.Text;
using System.Collections.Generic;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace InsertUpdateDeleteDemo
{
    public partial class frmNotes : Form
    {

        public frmNotes()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(SQLConn.connectionString);
        public int NoteID;
        string today = DateTime.Now.ToString("dd/mm/yy HH:mm");

        private void GetNotesRecord()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select * from notes order by 1 desc", con);
                DataTable dt = new DataTable();

                con.Open();

                SqlDataReader sdr = cmd.ExecuteReader();
                dt.Load(sdr);
                con.Close();

                dataGridView1.VirtualMode = true;
                dataGridView1.DataSource = dt;

                if (dataGridView1.Rows.Count > 0)
                {
                    dataGridView1.Rows[0].Selected = false;
                }

                dataGridView1.Columns[0].HeaderCell.Value = "Transaction";
                dataGridView1.Columns[1].HeaderCell.Value = "Partenaire";
                dataGridView1.Columns[2].HeaderCell.Value = "Produit";
                dataGridView1.Columns[3].HeaderCell.Value = "Quantité";
                dataGridView1.Columns[4].HeaderCell.Value = "Prix";
                dataGridView1.Columns[5].HeaderCell.Value = "Date";
                dataGridView1.Columns[6].HeaderCell.Value = "Commentaires";
            }
            catch (Exception)
            {
            }
        }

        private bool IsValid()
        {
            if (txtPartner.Text == string.Empty)
            {
                MessageBox.Show("Nom du partenaire requis.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtProduct.Text == string.Empty)
            {
                MessageBox.Show("Produit requis.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtQuantity.Text == string.Empty)
            {
                MessageBox.Show("Quantité requise.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtPrice.Text == string.Empty)
            {
                MessageBox.Show("Prix requis.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                SqlCommand cmd = new SqlCommand("insert into notes values (@partner, @product, @quantity, @price, @date, @comment)", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@partner", txtPartner.Text);
                cmd.Parameters.AddWithValue("@product", txtProduct.Text);
                cmd.Parameters.AddWithValue("@quantity", txtQuantity.Text);
                cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@date", today);
                cmd.Parameters.AddWithValue("@comment", rtxtComments.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Nouvelle ligne ajoutée.", "Nouvelle entrée", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetNotesRecord();
                ResetFormControls();
            }
        }

        private void frmNotes_Load(object sender, EventArgs e)
        {
            GetNotesRecord();
            //dataGridView1_CellClick(dataGridView1, new DataGridViewCellEventArgs(0, 0));
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                if (NoteID > 0)
                {
                    SqlCommand cmd = new SqlCommand("update notes set partner=@partner, product=@product, quantity=@quantity, price=@price, date=@date, comment=@comment where noteid = @noteid", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@partner", txtPartner.Text);
                    cmd.Parameters.AddWithValue("@product", txtProduct.Text);
                    cmd.Parameters.AddWithValue("@quantity", txtQuantity.Text);
                    cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                    cmd.Parameters.AddWithValue("@date", today);
                    cmd.Parameters.AddWithValue("@comment", rtxtComments.Text);
                    cmd.Parameters.AddWithValue("@noteid", this.NoteID);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("La mise à jour a bien été effectuée.", "Mise à jour", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    GetNotesRecord();
                    ResetFormControls();
                }
                else
                {
                    MessageBox.Show("Vous devez d'abord sélectioner une ligne.", "Mise à jour", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (NoteID > 0)
            {
                SqlCommand cmd = new SqlCommand("delete from notes where noteid = @noteid", con);
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@noteid", this.NoteID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("La ligne sélectionnée a bien été supprimée.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetNotesRecord();
                ResetFormControls();
            }
            else
            {
                MessageBox.Show("Vous devez d'abord sélectionné une ligne.", "Suppression", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetFormControls();
        }

        private void ResetFormControls()
        {
            NoteID = 0;
            txtPartner.Clear();
            txtProduct.Clear();
            txtQuantity.Clear();
            txtPrice.Clear();
            //txtDate.Clear();
            rtxtComments.Clear();
            txtPartner.Focus();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                    NoteID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                txtPartner.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                txtProduct.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                txtQuantity.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                txtPrice.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                rtxtComments.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
                //txtDate.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            }
            catch (Exception)
            {
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void picMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Utility.ExportToExcel(dataGridView1);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //dataGridView1 = string.Format("Title LIKE '%{0}%' OR AUTHOR LIKE '%{0}%' OR Name LIKE '%{0}%'

            /*try
            {

                var bindData = (BindingSource)dataGridView1.DataSource;
                var dataTable = (DataTable)bindData.DataSource;
                dataTable.DefaultView.RowFilter = string.Format("Student_Username LIKE '%{0}%'", txtSearch.Text);
                dataGridView1.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/
        }

        private DataTable PopulateDataGridView()
        {
            string query = "SELECT noteid, partner, product, quantity, price, date, comment FROM notes";
            query += " WHERE noteid LIKE '%' + @SearchTerm + '%'";
            query += " OR partner LIKE '%' + @SearchTerm + '%'";
            query += " OR product LIKE '%' + @SearchTerm + '%'";
            query += " OR quantity LIKE '%' + @SearchTerm + '%'";
            query += " OR price LIKE '%' + @SearchTerm + '%'";
            query += " OR date LIKE '%' + @SearchTerm + '%'";
            query += " OR comment LIKE '%' + @SearchTerm + '%'";
            query += " OR @SearchTerm = ''";
            string constr = SQLConn.connectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@SearchTerm", txtSearch.Text.Trim());
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        private void txtSearch_KeyUp(object sender, KeyEventArgs e)
        {
            dataGridView1.VirtualMode = true;
            dataGridView1.DataSource = this.PopulateDataGridView();
        }

        private void rtxtComments_TextChanged(object sender, EventArgs e)
        {

        }

        private void ToolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void lblFormTitle_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtPrice.Text, "  ^ [0-9]"))
            {
                txtPrice.Text = "";
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtProduct_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void ToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtQuantity.Text, "  ^ [0-9]"))
            {
                txtQuantity.Text = "";
            }
        }

        private void txtPartner_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void gbxComments_Enter(object sender, EventArgs e)
        {

        }

        private void gbxSearch_Enter(object sender, EventArgs e)
        {

        }

        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            Utility.onlynumwithsinglecomma(sender, e);
        }

        
    }
}
