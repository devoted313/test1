﻿using Microsoft.VisualBasic;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EMS
{
    public partial class frmSystemSetting : Form
    {

        bool isAddingVat;

        public frmSystemSetting()
        {
            InitializeComponent();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmSystemSetting_Load(object sender, EventArgs e)
        {
            //Company Setting
            txtName.Tag = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtPhoneNo.Text = "";
            txtEmail.Text = "";
            txtWebsite.Text = "";
            txtTINNumber.Text = "";
            GetCompanyInfo();

            //VAT Setting
            txtPercent.Text = "";
            GetVATInfo();

        }
#region "Company"

     
        public void AddEditCompany(bool isAdding)
        {
            try
            {
                if (isAdding == true)
                {
                    SQLConn.sql = "INSERT INTO Company(Name, Address, PhoneNo, Email, Website, TINNumber) VALUES(@Name, @Address, @PhoneNo, @Email, @Website, @TINNumber)";
                }
                else
                {
                    SQLConn.sql = "UPDATE Company SET Name=@Name, Address=@Address, PhoneNo=@PhoneNO, Email=@Email, Website=@Website, TINNumber =@TINNumber WHERE CompanyID=@CompanyID ";
                }
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);

                SQLConn.command.Parameters.AddWithValue("@Name", txtName.Text);
                SQLConn.command.Parameters.AddWithValue("@Address", txtAddress.Text);
                SQLConn.command.Parameters.AddWithValue("@PhoneNo", txtPhoneNo.Text);
                SQLConn.command.Parameters.AddWithValue("@Email", txtEmail.Text);
                SQLConn.command.Parameters.AddWithValue("@Website", txtWebsite.Text);
                SQLConn.command.Parameters.AddWithValue("@TINNumber", txtTINNumber.Text);
                
                if (isAdding == false)
                {
                    SQLConn.command.Parameters.AddWithValue("@CompanyID", txtName.Tag);
                }

                int i = SQLConn.command.ExecuteNonQuery();
                if (i > 0)
                {
                    if (isAdding == true)
                    {
                        Interaction.MsgBox("Les informations sur l'entreprise ont été ajoutées à jour avec succès", MsgBoxStyle.Information, "Ajout de l'entreprise");
                    }
                    else
                    {
                        Interaction.MsgBox("Les informations sur l'entreprise ont été mises à jour avec succès", MsgBoxStyle.Information, "Mise à jour de l'entreprise");
                    }
                }
                else
                {
                    Interaction.MsgBox("L'enregistrement des informations de l'entreprise a échoué", MsgBoxStyle.Exclamation, "Echec");
                }

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        public void GetCompanyInfo()
        {
            try
            {
                SQLConn.sql = "SELECT CompanyID, Name, Address, PhoneNo, Email, Website, TINNumber FROM Company";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();


                if (SQLConn.reader.Read())
                {
                    txtName.Tag = SQLConn.reader[0].ToString();
                    txtName.Text = SQLConn.reader[1].ToString();
                    txtAddress.Text = SQLConn.reader[2].ToString();
                    txtPhoneNo.Text = SQLConn.reader[3].ToString();
                    txtEmail.Text = SQLConn.reader[4].ToString();
                    txtWebsite.Text = SQLConn.reader[5].ToString();
                    txtTINNumber.Text = SQLConn.reader[6].ToString();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        private bool IsAdding()
        {
            bool ret = false;
            try
            {
                SQLConn.sql = "SELECT * FROM Company";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();
                if (SQLConn.reader.Read() == true)
                {
                    ret = false;
                }
                else
                {
                    ret = true;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
            return ret;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddEditCompany(IsAdding());
        }

#endregion

#region "VAT"

        public void AddEditVAT(bool isAdding)
        {
            try
            {
            
                if (isAdding == true)
                {
                    SQLConn.sql = "INSERT INTO VATSetting(VatPercent) VALUES(@VatPercent)";
                }
                else
                {
                    SQLConn.sql = "UPDATE VATSetting SET VatPercent=@VatPercent WHERE VATID=@VATID ";
                }
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);

                SQLConn.command.Parameters.AddWithValue("@VatPercent", txtPercent.Text);
               
                if (isAdding == false)
                {
                    SQLConn.command.Parameters.AddWithValue("@VATID", txtPercent.Tag);
                }

                int i = SQLConn.command.ExecuteNonQuery();
                if (i > 0)
                {
                    if (isAdding == true)
                    {
                        Interaction.MsgBox("La TVA a été ajoutée avec succès", MsgBoxStyle.Information, "Ajout de la TVA");
                    }
                    else
                    {
                        Interaction.MsgBox("La TVA a été modifiée avec succès", MsgBoxStyle.Information, "Mise à jour de la TVA");
                    }

                }
                else
                {
                    Interaction.MsgBox("La TVA n'a pas pu se mettre à jour", MsgBoxStyle.Exclamation, "Echec");
                }

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }

        public void GetVATInfo()
        {
            try
            {
                SQLConn.sql = "SELECT VATID, VatPercent FROM VatSetting";
                SQLConn.ConnDB();
                SQLConn.command = new SqlCommand(SQLConn.sql, SQLConn.connection);
                SQLConn.reader = SQLConn.command.ExecuteReader();


                if (SQLConn.reader.Read())
                {
                    txtPercent.Tag = SQLConn.reader[0];
                    txtPercent.Text = SQLConn.reader[1].ToString();
                    isAddingVat = false;
                }
                else
                {
                    isAddingVat = true;
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                SQLConn.command.Dispose();
                SQLConn.connection.Close();
            }
        }


#endregion

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtPercent.Text == "")
            {
                AddEditVAT(isAddingVat);
            }
            else
            {
                AddEditVAT(isAddingVat);
            }
        }

    }
}
