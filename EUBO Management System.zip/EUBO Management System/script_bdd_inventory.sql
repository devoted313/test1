CREATE TABLE [dbo].[category] (
    [CategoryNo]   INT           NOT NULL,
    [CategoryName] VARCHAR (45)  NOT NULL,
    [Description]  VARCHAR (150) NOT NULL
);

CREATE TABLE [dbo].[company] (
    [CompanyID] INT           NOT NULL,
    [Name]      VARCHAR (250) NOT NULL,
    [Address]   VARCHAR (250) NULL,
    [PhoneNo]   VARCHAR (45)  NULL,
    [Email]     VARCHAR (100) NULL,
    [Website]   VARCHAR (100) NULL,
    [TINNumber] VARCHAR (100) NULL,
    [HInvoice]  INT           NOT NULL
);

CREATE TABLE [dbo].[Employees] (
    [EmployeeID] NUMERIC (9)   IDENTITY (1, 1) NOT NULL,
    [LastName]   NVARCHAR (20) NOT NULL,
    [FirstName]  NVARCHAR (10) NOT NULL,
    [Title]      NVARCHAR (30) NULL,
    [HireDate]   DATETIME      NULL,
    [PostalCode] NVARCHAR (10) NULL
);

CREATE TABLE [dbo].[location] (
    [location_id]          INT           NOT NULL,
    [location_name]        VARCHAR (45)  NOT NULL,
    [location_description] VARCHAR (150) NOT NULL
);

CREATE TABLE [dbo].[measure_unit] (
    [measure_unit_id]          INT           NOT NULL,
    [measure_unit_name]        VARCHAR (45)  DEFAULT ('') NOT NULL,
    [measure_unit_description] VARCHAR (150) DEFAULT ('') NOT NULL
);

CREATE TABLE [dbo].[notes] (
    [noteId]   INT           IDENTITY (1, 1) NOT NULL,
    [partner]  VARCHAR (50)  NULL,
    [product]  VARCHAR (50)  NULL,
    [quantity] VARCHAR (50)  NULL,
    [price]    VARCHAR (50)  NULL,
    [date]     VARCHAR (15)  NULL,
    [comment]  VARCHAR (500) NULL,
    PRIMARY KEY CLUSTERED ([noteId] ASC)
);

CREATE TABLE [dbo].[partner] (
    [partner_id]          INT           NOT NULL,
    [partner_name]        VARCHAR (45)  DEFAULT ('') NOT NULL,
    [partner_description] VARCHAR (150) DEFAULT ('') NOT NULL
);

CREATE TABLE [dbo].[payment] (
    [paymentNo] INT        NOT NULL,
    [InvoiceNo] INT        DEFAULT ('0') NOT NULL,
    [Cash]      FLOAT (53) DEFAULT ('0') NOT NULL,
    [PChange]   FLOAT (53) DEFAULT ('0') NOT NULL,
    PRIMARY KEY CLUSTERED ([paymentNo] ASC),
    CHECK ([paymentNo]>(0)),
    CHECK ([InvoiceNo]>(0))
);

CREATE TABLE [dbo].[product] (
    [ProductNo]       INT           NOT NULL,
    [ProductCode]     VARCHAR (45)  DEFAULT ('') NULL,
    [Description]     VARCHAR (200) DEFAULT ('') NULL,
    [Barcode]         VARCHAR (50)  DEFAULT ('') NULL,
    [UnitPrice]       FLOAT (53)    DEFAULT ('0') NULL,
    [StocksOnHand]    FLOAT (53)    DEFAULT ('0') NULL,
    [ReorderLevel]    INT           DEFAULT ('0') NULL,
    [CategoryNo]      INT           DEFAULT ('0') NULL,
    [measure_unit_id] INT           NULL,
    [location_id]     INT           NULL,
    [partner_id]      INT           NULL
);

CREATE TABLE [dbo].[salesreturn] (
    [SalesReturnID]  INT           NOT NULL,
    [InvoiceNo]      VARCHAR (45)  DEFAULT ('') NOT NULL,
    [VatAmount]      FLOAT (53)    DEFAULT ('0') NOT NULL,
    [SubTotalAmount] FLOAT (53)    DEFAULT ('0') NOT NULL,
    [TotalAmount]    FLOAT (53)    DEFAULT ('0') NOT NULL,
    [UserID]         INT           DEFAULT ('0') NOT NULL,
    [ReturnDate]     DATETIME2 (7) NOT NULL,
    PRIMARY KEY CLUSTERED ([SalesReturnID] ASC)
);

CREATE TABLE [dbo].[salesreturnitem] (
    [SRIID]     INT          NOT NULL,
    [InvoiceNo] VARCHAR (45) DEFAULT ('') NOT NULL,
    [ProductID] INT          DEFAULT ('0') NOT NULL,
    [Quantity]  FLOAT (53)   DEFAULT ('0') NOT NULL,
    PRIMARY KEY CLUSTERED ([SRIID] ASC),
    CHECK ([SRIID]>(0))
);

CREATE TABLE [dbo].[staff] (
    [StaffID]   INT          NOT NULL,
    [Lastname]  VARCHAR (45) DEFAULT ('') NOT NULL,
    [Firstname] VARCHAR (45) DEFAULT ('') NOT NULL,
    [MI]        VARCHAR (1)  DEFAULT ('') NOT NULL,
    [Street]    VARCHAR (45) DEFAULT ('') NOT NULL,
    [Barangay]  VARCHAR (45) DEFAULT ('') NOT NULL,
    [City]      VARCHAR (45) DEFAULT ('') NOT NULL,
    [Province]  VARCHAR (45) DEFAULT ('') NOT NULL,
    [ContactNo] VARCHAR (45) DEFAULT ('') NOT NULL,
    [Username]  VARCHAR (45) DEFAULT ('') NOT NULL,
    [Role]      VARCHAR (45) DEFAULT ('') NOT NULL,
    [UPassword] VARCHAR (45) DEFAULT ('') NOT NULL,
    PRIMARY KEY CLUSTERED ([StaffID] ASC),
    CHECK ([StaffID]>(0))
);

CREATE TABLE [dbo].[stockin] (
    [StockInNo] INT          NOT NULL,
    [ProductNo] INT          DEFAULT ('0') NOT NULL,
    [Quantity]  FLOAT (53)   DEFAULT ('0') NOT NULL,
    [DateIn]    VARCHAR (45) DEFAULT ('') NOT NULL,
    [status]    INT          NULL,
    PRIMARY KEY CLUSTERED ([StockInNo] ASC)
);

CREATE TABLE [dbo].[stockout] (
    [StockOutNo] INT          NOT NULL,
    [ProductNo]  INT          NOT NULL,
    [Quantity]   FLOAT (53)   NOT NULL,
    [DateOut]    VARCHAR (45) NOT NULL,
    [status]     INT          NULL
);

CREATE TABLE [dbo].[transaction_type] (
    [transaction_type_id]          INT           NOT NULL,
    [transaction_type_name]        VARCHAR (45)  DEFAULT ('') NOT NULL,
    [transaction_type_description] VARCHAR (150) DEFAULT ('') NOT NULL,
    PRIMARY KEY CLUSTERED ([transaction_type_id] ASC)
);

CREATE TABLE [dbo].[transactiondetails] (
    [TDetailNo] INT          NOT NULL,
    [InvoiceNo] VARCHAR (50) DEFAULT ('') NOT NULL,
    [ProductNo] INT          DEFAULT ('0') NOT NULL,
    [ItemPrice] FLOAT (53)   DEFAULT ('0') NOT NULL,
    [Quantity]  FLOAT (53)   DEFAULT ('0') NOT NULL,
    [Discount]  FLOAT (53)   DEFAULT ('0') NOT NULL,
    [amount]    FLOAT (53)   NULL,
    PRIMARY KEY CLUSTERED ([TDetailNo] ASC),
    CHECK ([ProductNo]>(0))
);

CREATE TABLE [dbo].[transactions] (
    [InvoiceNo]            INT           NOT NULL,
    [TDate]                VARCHAR (45)  DEFAULT ('') NULL,
    [TTime]                VARCHAR (45)  DEFAULT ('') NULL,
    [NonVatTotal]          FLOAT (53)    DEFAULT ('0') NULL,
    [VatAmount]            FLOAT (53)    DEFAULT ('0') NULL,
    [TotalAmount]          VARCHAR (45)  DEFAULT ('') NULL,
    [StaffID]              INT           DEFAULT ('0') NULL,
    [Status]               INT           DEFAULT ('0') NULL,
    [transaction_type_id]  INT           NULL,
    [transaction_discount] FLOAT (53)    NULL,
    [transaction_comments] VARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([InvoiceNo] ASC)
);

CREATE TABLE [dbo].[credits] (
    [creditId] INT           IDENTITY (1, 1) NOT NULL,
    [partner]  VARCHAR (50)  NULL,
    [amount]   VARCHAR (50)  NULL,
    [date]     VARCHAR (15)  NULL,
    [comment]  VARCHAR (500) NULL,
    PRIMARY KEY CLUSTERED ([creditId] ASC)
);

CREATE TABLE [dbo].[charges] (
    [chargeId] INT           IDENTITY (1, 1) NOT NULL,
    [type]     VARCHAR (50)  NULL,
    [amount]   VARCHAR (50)  NULL,
    [date]     VARCHAR (15)  NULL,
    [comment]  VARCHAR (500) NULL,
    PRIMARY KEY CLUSTERED ([chargeId] ASC)
);
